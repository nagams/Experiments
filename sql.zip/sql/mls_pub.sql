@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\VERSIONED\SQL\mls_versioned_catalog_ddl.sql;

CREATE INDEX vzw_phcapability_grp_ws_idx ON vzw_phone_capability_group(workspace_id);
CREATE INDEX vzw_phcapability_grp_chkdt_idx ON vzw_phone_capability_group(checkin_date);
CREATE INDEX vzw_mkt_restrn_chkdt_idx ON vzw_market_restriction(checkin_date);
CREATE INDEX vzw_channel_restrn_chkdt_idx ON vzw_channel_restriction(checkin_date);
CREATE INDEX VZW_CUSTYPE_RESTRN_WS_IDX ON VZW_CUST_TYPE_RESTRICTION(WORKSPACE_ID);
CREATE INDEX vzw_custype_restrn_chkdt_idx ON vzw_cust_type_restriction(checkin_date);

ALTER TABLE VZW_MARKET ADD B2C_NET_ACE_LOCATION VARCHAR2(254);
ALTER TABLE VZW_MARKET ADD WAREHOUSE_ID VARCHAR2(254);
ALTER TABLE VZW_PRODUCT ADD DESCRIPTION VARCHAR2(2000);
ALTER TABLE VZW_SKU ADD SOR_CODE VARCHAR2(40 BYTE);
ALTER TABLE VZW_SKU ADD DESCRIPTION VARCHAR2(2000);

CREATE TABLE VZW_SKU_TO_COLOR (	
      SKU_ID VARCHAR2(254 BYTE) NOT NULL, 
      SKU_COLOR_ID VARCHAR2(254 BYTE), 
      asset_version           int not null,
      PRIMARY KEY (SKU_ID, asset_version)
);

drop table VZW_DEVICE_TO_ACCESSORY;

CREATE TABLE VZW_DEVICE_TO_ACCESSORY (	
        PRODUCT_ID VARCHAR2(254 BYTE), 
	    ACCESSORY_ID VARCHAR2(254 BYTE), 
        asset_version           int not null,
        sec_asset_version	number(19)	not null,

        PRIMARY KEY(product_id, ACCESSORY_ID, asset_version, sec_asset_version)
   );

select * from dpi_user;

SELECT * FROM DAS_DEPLOYMENT;
