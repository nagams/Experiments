DELETE FROM EPUB_PR_HISTORY;
DELETE FROM EPUB_PR_HISTORY WHERE PROJECT_ID='prj19001';
select * from epub_pr_history;

DELETE FROM EPUB_PROJECT;
DELETE FROM EPUB_PROJECT WHERE PROJECT_ID='prj19001';
SELECT * FROM EPUB_PROJECT;
SELECT * FROM EPUB_PROJECT WHERE DISPLAY_NAME='Apple Test';
-- prj19001

SELECT * FROM EPUB_PROC_HISTORY;


SELECT * FROM EPUB_PROC_TASKINFO;


SELECT owner, table_name
  FROM ALL_CONSTRAINTS
 WHERE constraint_name = 'PROC_HIST_ID_FK';

DELETE FROM EPUB_PROC_TASKINFO;
DELETE FROM EPUB_PROC_HISTORY;
delete from epub_ind_workflow;
delete from epub_process;
delete from avm_asset_lock;
delete from avm_workspace;
delete from EPUB_TR_AGENTS;
delete from EPUB_TARGET;
delete from EPUB_TL_TARGETS;
delete from EPUB_PRJ_TG_SNSHT;
delete from EPUB_PR_HISTORY;
delete from EPUB_AGENT_TRNPRT;
delete from EPUB_INCLUD_ASSET;
delete from EPUB_PRINC_ASSET;
delete from EPUB_AGENT;
delete from EPUB_PR_TG_STATUS;
delete from EPUB_PROJECT;
delete from EPUB_PR_TG_AP_TS;
delete from EPUB_DEPLOYMENT;
delete from EPUB_PR_TG_DP_TS;
delete from EPUB_PROC_HISTORY;
DELETE FROM EPUB_PR_TG_DP_ID;
delete from EPUB_INT_PRJ_HIST;

delete from EPUB_PROJECT;
delete from EPUB_PROC_TASKINFO;
delete from EPUB_WORKFLOW_STRS;
delete from EPUB_IND_WORKFLOW;
DELETE FROM EPUB_PROCESS;
delete from avm_asset_lock;