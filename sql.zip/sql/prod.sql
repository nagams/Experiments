-----BEGIN: Initialize--------------
@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\SQL\MAS_AUDIT.SQL;
@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\SQL\MAS_AUDIT_DML.SQL;

 CREATE TABLE MAS_ORDER 
   (ORDER_ID VARCHAR2(40) NOT NULL, 
	MAS_ORDER_DETAIL_ID VARCHAR2(40), 
	POS_ORDER_ID VARCHAR2(40), 
	POS_LOCATION_ID VARCHAR2(40), 
	EMAIL VARCHAR2(100), 
	IS_BTA NUMBER(1) DEFAULT 0, 
	CONSTRAINT MAS_ORDER_PK PRIMARY KEY (ORDER_ID)
   );
   
      
   CREATE TABLE MAS_ORDER_DETAILS 
   (	MAS_ORDER_DETAIL_ID VARCHAR2(40 BYTE) NOT NULL ENABLE, 
	PROMO_CODE VARCHAR2(40 BYTE), 
	OFFER_DESC VARCHAR2(250 BYTE), 
	ORDER_DISCOUNT_AMOUNT NUMBER, 
	SHIPPING_METHOD VARCHAR2(40 BYTE), 
	SHIPPING_DESC VARCHAR2(250 BYTE), 
	TAX_AMOUNT NUMBER, 
	SHIPPING_AMOUNT NUMBER
   ) ;

@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\COMMERCE\SQL\USER_AGENT.SQL;
@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\COMMERCE\SQL\MISC_DDL.SQL;
@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\COMMERCE\SQL\ratings_ddl.sql;

@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\COMMERCE\SQL\CREATE_CONTENT_REPOSITORY.SQL;   

CREATE TABLE MAS_EXTERNAL_URLS (
     id                        VARCHAR2(32)     not null references MAS_CONTENT_ITEM(CONTENT_ID),
     URL_KEY                  VARCHAR2(128)    not null,
     URL_VALUE              VARCHAR2(1000),
     CONSTRAINT MAS_EXTERNAL_URLS_P PRIMARY KEY (ID, URL_KEY)
);


VARCHAR2(4000)

desc endeca_response;

drop table endeca_response;

CREATE TABLE endeca_response	
(
  PAGE_ID	             VARCHAR2(254 BYTE) NOT NULL,
  RESPONSE_CONTENT     CLOB,
  MODIFIED_DATE        DATE,
  primary key(page_id)
);

select * from endeca_response;

delete from endeca_response;

@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\COMMERCE\SQL\INSERT_ERROR_CODES.SQL;
@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\COMMON\INTEGRATIONS\SQL\MLS\CORE\MLS_SKU_RATINGS.SQL;
--@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\COMMON\INTEGRATIONS\SQL\MLS\CORE\VZW_ZIP_MARKET.SQL;

-------END: initialize-------------
SELECT * FROM MLS_SKU_RATINGS;

SELECT * FROM VZW_REBATE_ACCESSORY_DETAIL;
SELECT * FROM VZW_REBATE_ACCESSORY_MASTER;
select * from VZW_INVENTORY_ITEM_LOCATION;

@C:\USERS\C0SETN1\WORKSPACE\TEST-ATG-STREAM\MODULES\MAS\SQL\DROP_MISC_DDL.SQL;
@C:\Users\c0setn1\workspace\Test-Atg-Stream\modules\mas\sql\misc_ddl.sql;

@C:\USERS\C0SETN1\DOCUMENTS\CA\VZW_MARKET.SQL;
@C:\USERS\C0SETN1\DOCUMENTS\CA\VZW_ZIP_MARKET.SQL;


SELECT * FROM VZW_MARKET;
SELECT * FROM VZW_ZIP_MARKET;

SELECT * FROM DCSPP_ORDER;
SELECT * FROM DCSPP_ITEM WHERE ORDER_REF='SM46002';
SELECT * FROM DCSPP_SHIP_GROUP WHERE ORDER_REF='SM46002';
SELECT * FROM DCSPP_ORDER_SG WHERE ORDER_ID='SM46002';
SELECT * FROM DCSPP_ORDER WHERE PROFILE_ID='180002';
SELECT COUNT(*) FROM DCSPP_ORDER;
SELECT * FROM DCSPP_SHIP_GROUP;
SELECT * FROM DCSPP_SHIP_GROUP WHERE ORDER_REF='230001';
SELECT * FROM DCSPP_SHIP_ADDR;

SELECT * FROM DCSPP_SHIP_ADDR WHERE SHIPPING_GROUP_ID IN (SELECT SHIPPING_GROUP_ID FROM DCSPP_SHIP_GROUP WHERE ORDER_REF='260001');




UPDATE DCSPP_ORDER SET PROFILE_ID=101 WHERE ORDER_ID='260001';
commit;

select * from core.das_id_generator;

select * from core.das_id_generator where id_space_name like '%user%';

--Check if DAS_ID_GENERATOR is empty
--if not, then do 
      -- DELETE FROM DAS_ID_GENERATOR;
INSERT INTO DAS_ID_GENERATOR (ID_SPACE_NAME, SEED, BATCH_SIZE, PREFIX)  VALUES  ('order', 1, 1000, 'SM');

INSERT INTO DAS_ID_GENERATOR (ID_SPACE_NAME, SEED, BATCH_SIZE, PREFIX)  VALUES  ('NGorder', 1, 1000, 'SM');

SELECT * FROM DAS_ID_GENERATOR WHERE ID_SPACE_NAME='NGorder';
SELECT * FROM DSS_SERVER_ID;
SELECT * FROM DPS_USER_SCENARIO;
SELECT * FROM DPS_USER_ROLES;
SELECT * FROM DPS_USER;
SELECT ID, LOGIN, SECURITYSTATUS FROM DPS_USER WHERE LOGIN='nag';

UPDATE DPS_USER SET SECURITYSTATUS=0 WHERE LOGIN='nag';
commit;

SELECT DISTINCT OBJECT_NAME FROM USER_OBJECTS WHERE OBJECT_TYPE = 'TABLE';

-- ECPD -------------
SET DEFINE OFF;

CREATE OR REPLACE FORCE VIEW B2E_AUTH_TRANS
(
   ID,
   EMAIL_ADDR,
   UNIQUE_TOKEN_IND,
   TOKEN,
   TOKEN_START_DATE,
   TOKEN_END_DATE,
   CREATE_DATE,
   CREATE_BY,
   MODIFIED_DATE,
   MODIFIED_BY,
   ECPD_PROFILE_ID
)
AS
   (SELECT "ID",
           "EMAIL_ADDR",
           "UNIQUE_TOKEN_IND",
           "TOKEN",
           "TOKEN_START_DATE",
           "TOKEN_END_DATE",
           "CREATE_DATE",
           "CREATE_BY",
           "MODIFIED_DATE",
           "MODIFIED_BY",
           "ECPD_PROFILE_ID"
      FROM VZMLS_QC_CORE.B2E_DOMAIN_AUTH_V);

DROP TABLE B2E_AUTH_TRANS;

CREATE TABLE VZMLS_QC_CORE.B2E_DOMAIN_AUTH_V
(
  ID                NUMBER                      NOT NULL,
  EMAIL_ADDR        VARCHAR2(128 BYTE)          NOT NULL,
  UNIQUE_TOKEN_IND  VARCHAR2(1 BYTE),
  TOKEN             VARCHAR2(128 BYTE)          NOT NULL,
  TOKEN_START_DATE  DATE,
  TOKEN_END_DATE    DATE,
  CREATE_DATE       DATE,
  CREATE_BY         DATE,
  MODIFIED_DATE     DATE,
  MODIFIED_BY       VARCHAR2(20 BYTE),
  ECPD_PROFILE_ID   VARCHAR2(1024 BYTE)         NOT NULL
)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

Insert into B2E_DOMAIN_AUTH_V
   (ID, EMAIL_ADDR, UNIQUE_TOKEN_IND, TOKEN, TOKEN_START_DATE, 
    TOKEN_END_DATE, CREATE_DATE, MODIFIED_DATE, MODIFIED_BY, ECPD_PROFILE_ID)
 Values
   (2737, 'lia.fernandez@verizonwireless.com', 'Y', '3cxkl70do4iWkKKXAk4i6TrXJd232BKgp00nrzZ6rK5t42dQ0wdpWQv9SfSeazBtjvKIm877L5yCT1xapv181RG748T1AuOXZ5Pz23uZ0n0X84X8wns7r5pr8uOIe99h', TO_DATE('07/18/2008 17:02:29', 'MM/DD/YYYY HH24:MI:SS'), 
    TO_DATE('12/31/9999 17:02:29', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('07/18/2008 17:12:17', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('07/18/2008 17:12:17', 'MM/DD/YYYY HH24:MI:SS'), 'lfernan', '815125');
    
    
SELECT * FROM B2E_DOMAIN_AUTH_V;

update B2E_DOMAIN_AUTH_V set token='BbibSh00hYtxajc75EKBpp1a40b44fw9w02unszCX4kMD81NN8h66uTCxbO0WuVihvsx4x9R9l7rhxV8hn6fB950KWHee87HO2zbJfiBzEF17HJNY8389qA2Xs45NsS7' where id='2737';
COMMIT;

(SELECT "ID",
           "EMAIL_ADDR",
           "UNIQUE_TOKEN_IND",
           "TOKEN",
           "TOKEN_START_DATE",
           "TOKEN_END_DATE",
           "CREATE_DATE",
           "CREATE_BY",
           "MODIFIED_DATE",
           "MODIFIED_BY",
           "ECPD_PROFILE_ID"
      FROM VZMLS_QC_CORE.B2E_AUTH_TRANS_V);
      
      select * from VZMLS_QC_CORE. B2E_DOMAIN_AUTH_V;
-- ECPD -------------

ALTER TABLE VZW_ORDER ADD CLIENT_ORDER_TYPE VARCHAR2(40);
update vzw_order set client_order_type=' ' where exists(select * from dcspp_order WHERE state IN ('SUBMITTED','INCOMPLETE'));

desc VZW_ITEM_PRICE;

CREATE TABLE VZW_SED_OFFER ( 
      ID VARCHAR2(40) NOT NULL, 
      OFFER_ID VARCHAR2(254) NULL, 
      OFFER_TYPE VARCHAR2(254) NULL, 
      OFFER_DESC VARCHAR2(254) NULL, 
      OFFER_AMOUNT VARCHAR2(254) NULL, 
      VERSION INTEGER NULL, PRIMARY KEY(ID) );
      
ALTER TABLE VZW_SHIPPING_GROUP ADD SED_OFFER VARCHAR2(40);  

ALTER TABLE VZW_ITEM_PORTABILITY_NUMBER ADD (VALIDATE_MDN_RESPONSE  VARCHAR2(254 BYTE));
ALTER TABLE VZW_VALIDATE_MDN_RESPONSE ADD (ETNI_VALIDATION_DATE  VARCHAR2(254 BYTE));
ALTER TABLE VZW_ORDER ADD (CREDIT_APPROVAL_STATUS  VARCHAR2(254 BYTE));
ALTER TABLE VZW_ORDER ADD (INT_ELIGIBILITY_CHECK  VARCHAR2(1 BYTE));
ALTER TABLE VZW_ORDER ADD (CREDIT_APPLICATION_NUM  NUMBER(30));
ALTER TABLE VZW_ORDER ADD (SECURITY_DEPOSIT_AMOUNT  VARCHAR2(254 BYTE));
ALTER TABLE VZW_ORDER ADD (CREDIT_ORDER_NUM  VARCHAR2(254 BYTE));

---------------------------------------------
desc vzw_user;

desc VZW_CREDIT_PREAUTH_RESPONSE;

select * DSS_COLL_SCENARIO;

select * from BEST_SELLER;

select * from das_id_generator;

-----------------------
select * FROM items_fulfillment_status;

SELECT t1.sku,
  t1.available,
  t1.availability_flow,
  t1.device_type,
  t1.exp_ship_date,
  t1.last_updated_ts
FROM items_fulfillment_status t1
WHERE t1.sku = 'MD525LL/A';


select count(*) from dcs_sku;

select * from dcspp_order;

desc dcspp_order;
select * from vzw_order;

select * from das_account where account_name='admin';

delete from das_account where account_name = 'admin';


------------------------
05/09/14
Alter table vzw_vision_feature ADD package_processing_code VARCHAR2(254);
Alter table vzw_vision_feature ADD insurance_code VARCHAR2(254);
Alter table vzw_vision_feature ADD action_indicator VARCHAR2(254);

create table vzw_aalcpc_plan_details(
account_number varchar2(20),
mtn_number varchar2(12),
current_price_plan_id varchar2(254),
new_price_plan_id varchar2(254),
curr_spl_feature_offer_id varchar2(254),
new_spl_feature_offer_id varchar2(254),
order_id varchar2(254),
status varchar2(20),
error_message varchar2(2000),
CREATE_DATE  DATE default SYSDATE );

create table vzw_calling_change_plan(
ORDER_ID varchar2(254) NOT NULL,
isCPC     NUMBER(  1   ) DEFAULT 1 ,
CREATE_DATE DATE default SYSDATE);

ALTER TABLE vzw_aalcpc_plan_details  ADD (
  PRIMARY KEY
  (order_id , account_number));

  ALTER TABLE   vzw_calling_change_plan ADD   (
  PRIMARY KEY
 (order_id ));
 
 
 CREATE TABLE vzw_store_locator
  (
    retail_id      INTEGER NOT NULL,
    STORE_NUMBER   VARCHAR2(254) NULL,
    VERIZON_NUMBER VARCHAR2(254) NULL,
    STORE_NAME     VARCHAR2(254) NULL,
    BUSINESS_NAME  VARCHAR2(254) NULL,
    STORE_TYPE     VARCHAR2(254) NULL,
    AREA           VARCHAR2(254) NULL,
    REGION         VARCHAR2(254) NULL,
    ADDRESS1       VARCHAR2(254) NULL,
    ADDRESS2       VARCHAR2(254) NULL,
    CITY           VARCHAR2(254) NULL,
    STATE          VARCHAR2(254) NULL,
    STATE_NAME     VARCHAR2(254) NULL,
    ZIP            VARCHAR2(254) NULL,
    ZIP_PLUS       VARCHAR2(254) NULL,
    PHONE_NUMBER   VARCHAR2(254) NULL,
    FAX_NUMBER     VARCHAR2(254) NULL,
    STORE_STATUS   VARCHAR2(254) NULL,
    OPENING_DATE DATE NULL,
    CLOSING_DATE DATE NULL,
    DIRECT             VARCHAR2(254) NULL,
    HOURS_SUN          VARCHAR2(254) NULL,
    HOURS_MON          VARCHAR2(254) NULL,
    HOURS_TUE          VARCHAR2(254) NULL,
    HOURS_WED          VARCHAR2(254) NULL,
    HOURS_THU          VARCHAR2(254) NULL,
    HOURS_FRI          VARCHAR2(254) NULL,
    HOURS_SAT          VARCHAR2(254) NULL,
    TECH_HOURS_SUN     VARCHAR2(254) NULL,
    TECH_HOURS_MON     VARCHAR2(254) NULL,
    TECH_HOURS_TUE     VARCHAR2(254) NULL,
    TECH_HOURS_WED     VARCHAR2(254) NULL,
    TECH_HOURS_THU     VARCHAR2(254) NULL,
    TECH_HOURS_FRI     VARCHAR2(254) NULL,
    TECH_HOURS_SAT     VARCHAR2(254) NULL,
    SOFTWARE_FLASH     VARCHAR2(254) NULL,
    PAYMENTS_ACCEPTED  VARCHAR2(254) NULL,
    LATINO_IND_FLAG    VARCHAR2(254) NULL,
    DISASTER_IMPACTED  VARCHAR2(254) NULL,
    DIS_COMMENTS       VARCHAR2(254) NULL,
    TEMPORARY_HOURS    VARCHAR2(254) NULL,
    SERVICES_AVAILABLE VARCHAR2(254) NULL,
    PREMIUM_RETAILER   VARCHAR2(254) NULL,
    SPECIAL_HOUR_FLAG  VARCHAR2(254) NULL,
    SUNDAY_SPECIAL_HOURS_DATE DATE NULL,
    MONDAY_SPECIAL_HOURS_DATE DATE NULL,
    TUESDAY_SPECIAL_HOURS_DATE DATE NULL,
    WEDNESDAY_SPECIAL_HOURS_DATE DATE NULL,
    THURSDAY_SPECIAL_HOURS_DATE DATE NULL,
    FRIDAY_SPECIAL_HOURS_DATE DATE NULL,
    SATURDAY_SPECIAL_HOURS_DATE DATE NULL,
    FIOS_FLAG            VARCHAR2(254) NULL,
    NETWORK_REPEATER     VARCHAR2(254) NULL,
    NETACE_LOCATION_CODE VARCHAR2(254) NULL,
    IN_STORE_PICKUP_FLAG VARCHAR2(254) NULL,
    LATITUDE             NUMBER(28, 10) NULL,
    LONGITUDE            NUMBER(28, 10) NULL,
    FIPSCODE             VARCHAR2(254) NULL,
    ENERGY_STAR_FLAG     VARCHAR2(254) NULL,
    PRIMARY KEY(retail_id)
  );


==================Trade In========
-- count: 5545
select * from device_trade_info_feed;
desc device_trade_info_feed;

--store proc/view has errors
select * from device_trade_manufacture;

-- count: 403
select * from device_trade_info;

--count: 2699
select * from device_question_answer;


select * from device_trade_info_feed where erc_manufacturer='Apple' and erc_model like '%4S%';
select * from device_trade_info_feed where erc_model_id='65604';
--65604 A1387 iPhone 4S 32GB - Verizon
select * from device_trade_info_feed a, device_trade_info b where a.erc_model_id = b.model_id and a.erc_model_id='65604';
select * from device_trade_info where model_id='65604';
select * from device_trade_info_feed a, device_question_answer b where a.erc_model_id = b.device_trade_in_id and a.erc_model_id='65604';
select * from device_question_answer where device_trade_in_id='65604';

drop table device_manufacturer;
drop table device_trade_model;
drop table device_trade_variation;
drop table device_modelvar_rel;
commit;

CREATE TABLE device_manufacturer	
(
  manufacturer_id	VARCHAR2(40 BYTE) NOT NULL,
  name	            VARCHAR2(254 BYTE),
  image	            VARCHAR2(254 BYTE),
  primary key(manufacturer_id)
);

CREATE TABLE device_trade_model
(
  device_id       VARCHAR2(40 BYTE) NOT NULL,
  sequence_num    INTEGER,
  manufacturer_id VARCHAR2(40 BYTE) references device_manufacturer(manufacturer_id),
  model_name      VARCHAR2(254 BYTE),
  submission_cnt  INTEGER,
  erc_model_id    NUMBER,
  primary key(device_id)
);

CREATE TABLE device_trade_variation
( 
  variation_id    VARCHAR2(40 BYTE) NOT NULL,
  variation_name  VARCHAR2(40 BYTE),
  variation_image VARCHAR2(254 BYTE),
  primary key(variation_id)
);

CREATE TABLE device_modelvar_rel
(
  device_id     VARCHAR2(40 BYTE) NOT NULL references device_trade_model(device_id),
  seq_num       INTEGER,
  variation_id  VARCHAR2(40 BYTE) NOT NULL references device_trade_variation(variation_id),
  primary key(device_id, seq_num)
)

select * from device_trade_model;
---------- 09/10/14
alter table vzw_online_order add IS_EMP_TERMS_CND_ACCEPTED      NUMBER(1);
alter table vzw_online_order add EMP_TERMS_CND_VERSION_ID       NUMBER;


ALTER TABLE VZW_ORDER_ITEM_ASSOCIATIONS
 DROP PRIMARY KEY CASCADE;

DROP TABLE VZW_ORDER_ITEM_ASSOCIATIONS CASCADE CONSTRAINTS;

CREATE TABLE VZW_ORDER_ITEM_ASSOCIATIONS
(
  ORDER_ID        VARCHAR2(40 BYTE),
  COLLECTION_KEY  VARCHAR2(40 BYTE),
  COLLECTION_ID   VARCHAR2(40 BYTE),
  CREATION_DATE   DATE                          DEFAULT (sysdate)
)
TABLESPACE ATG_DATA
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            MAXSIZE          UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX VZW_ORDER_ITEM_ASSOCIATIO_PK ON VZW_ORDER_ITEM_ASSOCIATIONS
(ORDER_ID, COLLECTION_KEY)
LOGGING
TABLESPACE ATG_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            MAXSIZE          UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
NOPARALLEL;


ALTER TABLE VZW_ORDER_ITEM_ASSOCIATIONS ADD (
  CONSTRAINT VZW_ORDER_ITEM_ASSOCIATIO_PK
  PRIMARY KEY
  (ORDER_ID, COLLECTION_KEY)
  USING INDEX VZW_ORDER_ITEM_ASSOCIATIO_PK
  ENABLE VALIDATE);


ALTER TABLE VZW_ICONIC_ITEM
 DROP PRIMARY KEY CASCADE;

DROP TABLE VZW_ICONIC_ITEM CASCADE CONSTRAINTS;

CREATE TABLE VZW_ICONIC_ITEM
(
  CONFIG_ITEM_ID               VARCHAR2(254 BYTE),
  SERVICE_ADDRESS_ID           VARCHAR2(254 BYTE),
  CONTRACT_TERM                VARCHAR2(254 BYTE),
  DOWN_PAYMENT                 NUMBER(28,20),
  FIRST_INSTALLMENT            NUMBER(28,20),
  FINANCE_CHARGE               NUMBER(28,20),
  TAX                          NUMBER(28,20),
  DUE_NOW                      NUMBER(28,20),
  IS_DOWN_PAYMENT              NUMBER(1),
  DEPLETION_TYPE               VARCHAR2(240 BYTE),
  DEVICE_ID                    VARCHAR2(240 BYTE),
  SIM_ID                       VARCHAR2(240 BYTE),
  PREPAID_PLAN_TYPE            VARCHAR2(240 BYTE),
  UPGRADE_REASON_CODES         VARCHAR2(240 BYTE),
  ACTIVATION_LATER             NUMBER(1),
  DEVICE_CPE                   NUMBER(1),
  SIM_CPE                      NUMBER(1),
  GLOBAL_INDICATOR             NUMBER(1),
  PRE_ORDER_INDICATOR          NUMBER(1),
  STORE_PICK_UP_INDICATOR      NUMBER(1),
  ACTIVATION_DATE              DATE,
  NW4G_INDICATOR               NUMBER(1),
  MTN_NUMBER                   VARCHAR2(40 BYTE),
  ADDTO_EXISTING_GROUP_NUMBER  VARCHAR2(40 BYTE),
  NEW_SUB_ACCOUNT_NUMBER       VARCHAR2(40 BYTE),
  IS_SHARE_PLAN_ASSOCIATED     NUMBER(1),
  SHARED_PLAN                  VARCHAR2(40 BYTE),
  SHIP_BY_DATE                 DATE,
  PLAN_SHARE_PRICE             NUMBER(19,7),
  MULTI_LINE_SEQ_NO            INTEGER,
  INSTALLMENT_NUMBER           VARCHAR2(250 BYTE),
  MIN_NUMBER                   VARCHAR2(40 BYTE),
  DACC_ID                      VARCHAR2(50 BYTE),
  SERVICE_PRICE                NUMBER(19,7),
  ISCAPTURESIGNATURE           NUMBER(1)        DEFAULT (0),
  NW3G_INDICATOR               NUMBER(1)        DEFAULT (0),
  LAST_ADDED_CONF_COMMITEMID   VARCHAR2(40 BYTE),
  OLD_ESN_NUMBER               VARCHAR2(40 BYTE),
  DEVICE_TYPE_INDICATOR        VARCHAR2(40 BYTE),
  DEVICE_INDICATOR             VARCHAR2(40 BYTE),
  MEA                          VARCHAR2(40 BYTE),
  CUST_TYPE                    VARCHAR2(40 BYTE),
  PRIMARY_ITEM_STATE           VARCHAR2(40 BYTE),
  UPGRADE_TYPE                 VARCHAR2(40 BYTE),
  REFUND_APPLIED_IND           VARCHAR2(20 BYTE),
  PRIMARY_REASON_CODE          VARCHAR2(20 BYTE),
  SECONDARY_REASON_CODE        VARCHAR2(20 BYTE),
  DEVICE_SYMPTOMS              VARCHAR2(250 BYTE),
  BILLING_SYSTEM               VARCHAR2(40 BYTE),
  IS_ALB_ASSOCIATED            NUMBER(1)
)
TABLESPACE ATG_DATA
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          80K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX VZW_ICONIC_ITEM_PK ON VZW_ICONIC_ITEM
(CONFIG_ITEM_ID)
LOGGING
TABLESPACE ATG_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
NOPARALLEL;


ALTER TABLE VZW_ICONIC_ITEM ADD (
  CHECK (IS_DOWN_PAYMENT IN (0, 1))
  ENABLE VALIDATE,
  CONSTRAINT VZW_ICONIC_ITEM_PK
  PRIMARY KEY
  (CONFIG_ITEM_ID)
  USING INDEX VZW_ICONIC_ITEM_PK
  ENABLE VALIDATE);

ALTER TABLE VZW_ICONIC_ITEM ADD (
  FOREIGN KEY (SERVICE_ADDRESS_ID) 
  REFERENCES VZW_ADDRESS_INFO (ADDR_INFO_ID)
  ENABLE VALIDATE);


ALTER TABLE VZW_LINE_SPO_IMPACT_DETAIL
 DROP PRIMARY KEY CASCADE;

DROP TABLE VZW_LINE_SPO_IMPACT_DETAIL CASCADE CONSTRAINTS;

CREATE TABLE VZW_LINE_SPO_IMPACT_DETAIL
(
  SFO_ID            VARCHAR2(254 BYTE),
  SFO_SOR_ID        VARCHAR2(254 BYTE),
  TYPE              VARCHAR2(254 BYTE),
  EFFECTIVE_DATE    DATE,
  ACTION_INDICATOR  VARCHAR2(1 BYTE),
  VERSION           NUMBER,
  CREATE_DATE       DATE                        DEFAULT sysdate
)
TABLESPACE ATG_DATA
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            MAXSIZE          UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index SYS_C0014870.
--  The object is created when the parent object is created.

ALTER TABLE VZW_LINE_SPO_IMPACT_DETAIL ADD (
  PRIMARY KEY
  (SFO_ID)
  USING INDEX
    TABLESPACE ATG_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                MAXSIZE          UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);

ALTER TABLE VZW_SPO_ACTION_DETAIL
 DROP PRIMARY KEY CASCADE;

DROP TABLE VZW_SPO_ACTION_DETAIL CASCADE CONSTRAINTS;

CREATE TABLE VZW_SPO_ACTION_DETAIL
(
  SPO_ID          VARCHAR2(254 BYTE),
  SPO_SOR_ID      VARCHAR2(254 BYTE),
  EFFECTIVE_DATE  DATE,
  METHOD_CODE     VARCHAR2(254 BYTE),
  ACTION          VARCHAR2(1 BYTE),
  SPO_LEVEL       VARCHAR2(1 BYTE),
  VERSION         NUMBER,
  CREATE_DATE     DATE                          DEFAULT sysdate
)
TABLESPACE ATG_DATA
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            MAXSIZE          UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index SYS_C0014868.
--  The object is created when the parent object is created.

ALTER TABLE VZW_SPO_ACTION_DETAIL ADD (
  PRIMARY KEY
  (SPO_ID)
  USING INDEX
    TABLESPACE ATG_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                MAXSIZE          UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);


ALTER TABLE VZW_ALB_ITEMS
 DROP PRIMARY KEY CASCADE;

DROP TABLE VZW_ALB_ITEMS CASCADE CONSTRAINTS;

CREATE TABLE VZW_ALB_ITEMS
(
  CONFIG_ITEM_ID  VARCHAR2(40 BYTE)             NOT NULL,
  ALB_ITEM_ID     VARCHAR2(40 BYTE)             NOT NULL,
  MODIFIED_DATE   DATE                          DEFAULT SYSDATE,
  MODIFIED_BY     VARCHAR2(50 BYTE)             DEFAULT NULL
)
TABLESPACE ATG_DATA
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            MAXSIZE          UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index SYS_C0014878.
--  The object is created when the parent object is created.

ALTER TABLE VZW_ALB_ITEMS ADD (
  PRIMARY KEY
  (CONFIG_ITEM_ID, ALB_ITEM_ID)
  USING INDEX
    TABLESPACE ATG_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                MAXSIZE          UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);
  

ALTER TABLE VZW_SPO_ACTIONS
 DROP PRIMARY KEY CASCADE;

DROP TABLE VZW_SPO_ACTIONS CASCADE CONSTRAINTS;

CREATE TABLE VZW_SPO_ACTIONS
(
  CONFIG_ITEM_ID  VARCHAR2(254 BYTE),
  SPO_ID          VARCHAR2(254 BYTE),
  SEQUENCE_NUM    NUMBER,
  CREATE_DATE     DATE                          DEFAULT sysdate
)
TABLESPACE ATG_DATA
