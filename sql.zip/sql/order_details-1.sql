--Order 
--old order: S1685602 S1711365, new:2102002758/S1734007
SELECT a.order_id, a.profile_id, a.state, a.creation_date, a.submitted_date, a.last_modified_date, a.price_info, a.tax_price_info, a.creation_site_id, a.site_id, b.is_credit_write_validated, b.optedfornewsletter, b.servicezip, b.vendor_id,b.channel_id,B.CREDIT_APPROVAL_STATUS,b.int_eligibility_check,b.credit_application_num  
  FROM ATGCORE.dcspp_order a, ATGCORE.VZW_ORDER b
 WHERE 
   b.client_reference_number = '2102002906'
    --   A.ORDER_ID = 'S1734012'
   AND A.ORDER_ID = B.ORDER_ID;


select * from atg_core.dcspp_order_inst where order_id='31698106764';
  
desc atgcore.dcspp_amount_info;
--sub total without tax
select * from atgcore.dcspp_amount_info where amount_info_id='SDC2471004';
-- tax amount
select * from atgcore.dcspp_amount_info where amount_info_id='SDC2471005';
--amounts both subtotal and tax
select * from atgcore.dcspp_order_price where amount_info_id='SDC2471004';

select * from atgcore.dcspp_shipitem_sub where amount_info_id='SDC2471004';

select * from atgcore.dcspp_taxshipitem where  amount_info_id='SDC2471004';
select * from atgcore.dcspp_ntaxshipitem where  amount_info_id='SDC2471004';

select * from atgcore.dcspp_amount_info where type=2;
--tax details
select * from atgcore.dcspp_tax_price where amount_info_id='SDC2471005';
select * from atgcore.dcspp_shipitem_tax where amount_info_id='SDC2471005';

-- Orders items
select * 
from atgcore.dcspp_item a, atgcore.vzw_item b, atgcore.vzw_online_item c 
where a.commerce_item_id in 
        (select commerce_items 
           from atgcore.dcspp_order_item 
          where order_id='S1760277')
  and a.commerce_item_id = b.commerce_item_id
  and B.COMMERCE_ITEM_ID = C.COMMERCE_ITEM_ID; 

select * 
from atgcore.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from atgcore.dcspp_order_item 
          where order_id='S1734007');

select * 
from atgcore.dcspp_item a, atgcore.dcspp_subsku_item b 
where a.commerce_item_id in 
        (select commerce_items 
           from atgcore.dcspp_order_item 
          where order_id='S1685602')
   and a.commerce_item_id = b.subsku_item_id;

select * from atgcore.dcspp_item where commerce_item_id like 'SDC2327316';

select * from atgcore.dcspp_item where commerce_item_id in (select commerce_items from atgcore.dcspp_item_ci where commerce_item_id='SDC2327314');

/* Formatted on 9/24/2014 5:09:25 PM (QP5 v5.252.13127.32847) */
--old config item: SDC2327314, New item:SDC2341001 
SELECT *
  FROM atgcore.dcspp_item a,atgcore.dcspp_subsku_item b, atgcore.VZW_SUBSKU_ITEM c 
 WHERE a.commerce_item_id IN (SELECT commerce_items
                              FROM atgcore.dcspp_item_ci
                             WHERE commerce_item_id = 'SDC2355175')
   AND a.commerce_item_id = b.subsku_item_id
   AND b.subsku_item_id = c.subsku_item_id;

select * from atgcore.vzw_item where commerce_item_id='SDC2341001';
select * from atgcore.vzw_online_item where commerce_item_id='SDC2341001';

select * from atgcore.dcspp_config_item;
select * from atgcore.dcspp_item_ci;
select * from atgcore.vzw_selected_option;
select * from atgcore.vzw_npanxx_number;
select * from atgcore.vzw_configCommerceItem;
select * from atgcore.vzw_item_portability_number;
select * from atgcore.vzw_vision_features;
select * from atgcore.vzw_device_accessories where config_item_id='SDC2308384';

select * from atgcore.dcspp_subsku_item;
select * from atgcore.dcspp_subsku_item where subsku_item_id='SDC2327318';
select * from atgcore.VZW_SUBSKU_ITEM;
select * from atgcore.VZW_SUBSKU_ITEM where subsku_item_id='SDC2327318';
select * from atgcore.dcspp_item_ci;
select * from atgcore.dcspp_item_ci where commerce_item_id='SDC2327314';
select commerce_items from atgcore.dcspp_item_ci where commerce_item_id='SDC2327314';

-- Items price info ids
select price_info 
from atgcore.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from atgcore.dcspp_order_item 
          where order_id='S1734007'); 
          
-- Items price details          
select * from atgcore.dcspp_item_price where amount_info_id in
 (select price_info 
from atgcore.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from atgcore.dcspp_order_item 
          where order_id='S1734007')); 

select * from atgcore.dcspp_itmprice_det where amount_info_id='SDC2471013';

select * from atgcore.dcspp_amount_info where amount_info_id='SDC2471014';

--Payment groups
select order_id, payment_groups from atgcore.dcspp_order_pg where order_id='S1734007';

select * from atgcore.dcspp_pay_group where order_ref='S1734007';

/* Formatted on 2009/07/30 14:47 (Formatter Plus v4.8.8) */
SELECT *
  FROM atg_core.dcspp_pay_group a, atg_core.dcspp_cardinal_paypal b
 WHERE a.order_ref = '3447159979' AND a.payment_group_id = b.payment_group_id;

select count(*) from atg_core.DCSPP_CARDINAL_PAYPAL;

select * from atg_core.dcspp_order where order_id in (SELECT order_ref
  FROM atg_core.dcspp_pay_group a, atg_core.dcspp_cardinal_paypal b
 WHERE a.payment_group_id = b.payment_group_id) and state != 'INCOMPLETE';

select * from atg_core.dcspp_pay_group where payment_group_id='pg598800038';

SELECT *
  FROM atgcore.dcspp_bill_addr
 WHERE payment_group_id IN (SELECT payment_groups
                              FROM atgcore.dcspp_order_pg
                             WHERE order_id = 'S1734007');



UPDATE atg_core.dcspp_pay_group
   SET amount = '244.95',
       amount_authorized = '244.95',
       amount_debited = '244.95',
       currency_code = 'USD',
       state = 'SETTLED',
       state_detail = 'The payment group was successfully debited.'
 WHERE order_ref = '3396505172';
 
 -- Payment Group Relationships
 
 -- Authorization
 --3443820211, 3442761933
select * from atg_core.dcspp_pay_group where order_ref='31698106764';
select * from atg_core.dcspp_pay_group where payment_group_id='pg1531689599';
select * from atg_core.dcspp_pay_group where payment_group_id like 'bf-pg%';

select * from atg_core.dcspp_credit_card where payment_group_id = 'pg1529096938';

select * from atg_core.dcspp_pay_group where order_ref in ('31677955649','31699086521','31708428199','31701928721','31708409645','31708549282','31300745889','31365638728','31708484199','31701750622','31707318169','31705376292','31708694012','31708719440','31708279776','31707480359','31683329313','31693491181','31705007364','31701732545','31706298993','31708731223','31708438942','31697914333','31706081558','31708518145','31708370048','31706528333','31705026422','31708493534','31707975068','31708424775','31703582484','31708527080','31561597106','31513058719','31578033365','31603600282','31497459756','31604586179')
and type = 1;

SELECT *
FROM atgcore.dcspp_credit_card
WHERE payment_group_id IN
  (SELECT payment_group_id
  FROM atgcore.dcspp_pay_group
  WHERE order_ref='S1734007'
  );

SELECT *
  FROM atg_core.dcspp_cardinal_paypal
 WHERE payment_group_id IN (SELECT payment_group_id
                              FROM atg_core.dcspp_pay_group
                             WHERE order_ref = '3659072061');
                             
--select * from atg_core.dcspp_bill_addr where payment_group_id='pg481662851';                             
SELECT *
  FROM atgcore.dcspp_auth_status
 WHERE payment_group_id IN (SELECT payment_group_id
                              FROM atgcore.dcspp_pay_group
                             WHERE order_ref = 'S1734007');

select * from atgcore.dcspp_pay_inst;
select * from atgcore.dcspp_auth_status;
select * from atgcore.dcspp_auth_status where payment_group_id='SDC4535008';

select * from atgcore.dcspp_debit_status where  payment_group_id='SDC4535008';

select * from atgcore.dcspp_debit_status where  payment_group_id IN (SELECT payment_group_id
                              FROM atgcore.dcspp_pay_group
                             WHERE order_ref = 'S1734007');
                             
select * from atg_core.dcspp_pay_status where status_id in (select debit_status from atg_core.dcspp_debit_status where  payment_group_id IN (SELECT payment_group_id
                              FROM atg_core.dcspp_pay_group
                             WHERE order_ref = '31711361053'));
                             
select * from atg_core.dcspp_pay_status where status_id ='ps120742763' ;
select * from atg_core.dcspp_pay_status where status_id like 'bfs558';
select * from atgcore.dcspp_cc_status where status_id='SDC587007';
select * from atg_core.dcspp_cardinalpp_status where status_id='ps42470331';

desc atg_core.dcspp_cardinalpp_status;

insert into atg_core.dcspp_cardinalpp_status values ('ps33270011'); 
 

--Shipping groups
select * from atgcore.dcspp_order_sg where order_id='S1734007';

select * from atgcore.dcspp_ship_group where order_ref='S1734007';

select * from atgcore.dcspp_ship_group where shipping_group_id like 'bf-sg%';
select * from atgcore.dcspp_amount_info where amount_info_id ='SDC2471006';
select * from atgcore.dcspp_ship_price  where amount_info_id ='SDC2471006';
select * from atgcore.dcspp_hrd_ship_grp where shipping_group_id in (select shipping_group_id from atgcore.dcspp_ship_group where order_ref='S1734007');

select * from atgcore.dcspp_ship_group where shipping_group_id='sg222962699';
select * from atgcore.dcspp_ship_addr where shipping_group_id='sg217730421';
SELECT *
  FROM atgcore.dcspp_ship_addr
 WHERE shipping_group_id IN (SELECT shipping_groups
                              FROM atgcore.dcspp_order_sg
                             WHERE order_id = 'S1734007');
                              
--select * from atg_core.dcspp_hand_inst;
--select * from atg_core.dcspp_ship_inst;
--select * from atg_core.dcspp_sg_hand_inst;
-- Relationships
-- 1> Payment group relationships
select * from atgcore.dcspp_order_rel where order_id='S1734007';
select * from atgcore.dcspp_relationship where order_ref='S1734007';
select * from atgcore.dcspp_relationship where relationship_id like 'r118742395';
select * from atgcore.dcspp_payorder_rel where order_id='S1734007';
select * from atgcore.dcspp_payorder_rel where relationship_id like 'bf-r-%';

select * from atgcore.dcspp_relationship where relationship_id='r110781319';

select * from atgcore.dcspp_shipitem_rel where relationship_id in (select relationship_id from atgcore.dcspp_relationship where order_ref='S1734007'); 
-- 2> Shipping group relationships

select * from atgcore.dcspp_rel_orders;
select * from atgcore.dcspp_order_sg where order_id='S1734007';
select * from atgcore.dcspp_order_pg where order_id='S1734007';
select * from atgcore.dcspp_order_item  where order_id='S1734007';

select * from atgcore.dcspp_order_rel where order_id='S1734007';           

select * from atg_core.dcspp_order_rel where order_id='3369811346' and relationships='r92993282';