
select * from atgcore.VZW_CQ_LABEL where content_key like '%PLAN_CONFIG_DATA%';

select * from atgcore.VZW_CQ_HTML where content_key like '%PLAN_CONFIG_DATA%' and site_id='PREPAY';

--PLAN_CONFIG_ADDITIONAL_FEATURES_TABLETS_CONTENT-desktop
select * from atgcore.VZW_CQ_HTML where content_key like 'PLAN_CONFIG_ADDITIONAL_FEATURES_TABLETS_CONTENT%' and site_id='PREPAY';

select * from atgcore.vzw_cq_label where content_key ='PLAN_LBL';


select * from atgcore.VZW_JVM_ID_SPACE;

select * from atgcore.VZW_JVM_ID_SPACE where shut_down_flag=1;

select * from atgcore.DAS_ID_GENERATOR;

select * from atgcore.DAS_ID_GENERATOR where id_space_name='cisOrder';

select * from atgcore.DAS_ID_GENERATOR where id_space_name='price';

select * from atgcore.vzw_internal_props where prop_name='CIS_ORDER_ID_GENERATOR_KILL_SWITCH'; 

select count(*) from atgcore.pos_order_status;

select * from atgcore.pos_order_status where netace_order_num='000270662';

desc atgcore.vzw_order;

desc atgcore.dcspp_order;

select * from atgcore.dps_user;

select * from atgcore.dps_user a, ATGCORE.VZW_SSO b where A.ID = B.VZW_USER_ID and B.VZW_MOBILE_NUMBER='2015729422';
--SDC6683135

select * from atgcore.dcspp_order a where A.PROFILE_ID='SDC6683135'; 

select * from atgcore.dcspp_order_rel where order_id='2100294450';

select * from atgcore.dcspp_relationship where relationship_id='SDC276007';

select * from atgcore.dcspp_order a where A.ORDER_ID in ('2104018300', '2103494655', '2103593981', '5101902029', '2103370266', '2103614414', '2100369010', '5102040159', '5102297495', '5102721113', '2100294450', '5102306043', '5102616320', '2100059002');


select * from atgcore.dcs_price_list;

select * from atgcata.vzw_sku where sor_id like 'JAWBONEUP%';

select * from atgcata.dcs_product;

select * from atgcata.ATG_SKU_OFFER_DTL;

SELECT DISTINCT DBCMAN.MANUFACTURER_NAME AS MAKE,
  VZWSKU.DISPLAY_NAME                    AS DISPLAY_NAME,
  vzwsku.prod_name                       AS PROD_NAME,
  VZWPROD.PRODUCT_ID                     AS MODEL,
  VZWPROD.IMAGE_NAME                     AS FILEPATH_MINI
FROM atgcata.DCS_PRODUCT DCSPROD,
  atgcata.VZW_PRODUCT VZWPROD,
  atgcata.DBC_MANUFACTURER DBCMAN,
  atgcata.VZW_MANUFACTURER VZWMAN,
  atgcata.VZW_SKU VZWSKU,
  atgcata.DCS_PRD_CHLDSKU CHLDSKU,
  atgcata.DCS_SKU DCSSKU,
  atgcata.VZW_SKU_DEVICE SKUDEVICE,
  atgcata.DCS_PRD_CATALOGS PRDCATALOG,
  atgcata.DCS_CATALOG CATALOG,
  atgcata.DCS_PRODUCT_SITES PRODSITE
WHERE DCSPROD.PRODUCT_ID   = VZWPROD.PRODUCT_ID
AND DBCMAN.MANUFACTURER_ID = VZWMAN.MANUFACTURER_ID
AND DCSPROD.PRODUCT_TYPE   = '1001'
AND VZWPROD.ACTIVE_FLAG    = 1
AND VZWPROD.PRODUCT_ID     = CHLDSKU.PRODUCT_ID
AND CHLDSKU.SKU_ID         = DCSSKU.SKU_ID
AND DCSSKU.SKU_ID          = VZWSKU.SKU_ID
AND VZWSKU.SKU_ID          = SKUDEVICE.SKU_ID
AND PRDCATALOG.PRODUCT_ID  = CHLDSKU.PRODUCT_ID
AND PRDCATALOG.CATALOG_ID  = CATALOG.CATALOG_ID
AND CATALOG.DISPLAY_NAME   = 'mlsstore'
AND VZWSKU.ACTIVE_FLAG     = 1
AND PRODSITE.PRODUCT_ID    = DCSPROD.PRODUCT_ID
AND PRODSITE.SITE_ID       = '200001'
AND vzwsku.display_name NOT LIKE '%Certified Pre-Owned%'
AND vzwsku.display_name NOT LIKE '%Prepaid%'
AND vzwsku.prod_name IS NOT NULL
AND DBCMAN.MANUFACTURER_NAME ='Samsung'
AND vzwsku.prod_name like '%Galaxy%';

select count(*) from atgcata.DBC_MANUFACTURER DBCMAN;
select count(*) from atgcata.VZW_MANUFACTURER VZWMAN;

select *
from atgcata.dcs_product
where product_id = 'dev440075';

select *
from atgcata.VZW_PRODUCT
where product_id = 'dev440075';

select *
from atgcata.dcs_product
where PRODUCT_TYPE   = '1003';

select * from atgcata.dcs_product_sites where product_id='dev440075';

select * from atgcata.vzw_sku;

select *
from atgcata.dcs_product a, atgcata.VZW_PRODUCT b
where a.PRODUCT_TYPE   = '1003'
    and a.product_id = b.product_id;

--100017

/* Formatted on 4/22/2014 6:16:49 PM (QP5 v5.252.13127.32847) */
  SELECT DISTINCT --DBCMAN.MANUFACTURER_NAME AS MAKE,
                  VZWSKU.DISPLAY_NAME AS DISPLAY_NAME,
                  vzwsku.prod_name AS PROD_NAME,
                  VZWPROD.PRODUCT_ID AS MODEL,
                  VZWPROD.ACTIVE_FLAG,
                  VZWPROD.SHOWCASE_IND as SHOWCASE_FLAG,
                  VZWPROD.IMAGE_NAME AS FILEPATH_MINI,
                  DCSPROD.PRODUCT_ID
    FROM atgcata.DCS_PRODUCT DCSPROD,
         atgcata.VZW_PRODUCT VZWPROD,
         --atgcata.DBC_MANUFACTURER DBCMAN,
         --atgcata.VZW_MANUFACTURER VZWMAN,
         atgcata.VZW_SKU VZWSKU,
         atgcata.DCS_PRD_CHLDSKU CHLDSKU,
         atgcata.DCS_SKU DCSSKU,
         atgcata.VZW_SKU_DEVICE SKUDEVICE,
         atgcata.DCS_PRD_CATALOGS PRDCATALOG,
         atgcata.DCS_CATALOG CATALOG,
         atgcata.DCS_PRODUCT_SITES PRODSITE
   WHERE     DCSPROD.PRODUCT_ID = VZWPROD.PRODUCT_ID
         --AND DCSPROD.MANUFACTURER = DBCMAN.MANUFACTURER_ID
         --AND DBCMAN.MANUFACTURER_ID = VZWMAN.MANUFACTURER_ID
         AND DCSPROD.PRODUCT_TYPE = '1001'
         AND VZWPROD.ACTIVE_FLAG = 1
         AND VZWPROD.PRODUCT_ID = CHLDSKU.PRODUCT_ID
         AND CHLDSKU.SKU_ID = DCSSKU.SKU_ID
         AND DCSSKU.SKU_ID = VZWSKU.SKU_ID
         AND VZWSKU.SKU_ID = SKUDEVICE.SKU_ID
         AND PRDCATALOG.PRODUCT_ID = CHLDSKU.PRODUCT_ID
         AND PRDCATALOG.CATALOG_ID = CATALOG.CATALOG_ID
         AND CATALOG.DISPLAY_NAME = 'mlsstore'
         AND VZWSKU.ACTIVE_FLAG = 1
         AND PRODSITE.PRODUCT_ID = DCSPROD.PRODUCT_ID
         AND PRODSITE.SITE_ID = '200001'
         AND vzwsku.display_name NOT LIKE '%Certified Pre-Owned%'
         AND vzwsku.display_name NOT LIKE '%Prepaid%'
         AND vzwsku.prod_name IS NOT NULL
         --AND DBCMAN.MANUFACTURER_NAME ='Samsung'
         AND dcsprod.product_id = 'dev440075'
ORDER BY DCSPROD.product_id;


select * from atgcata.vzw_wms_device_to_accessory;

select * from atgcata.vzw_wms_device_to_accessory where product_id='dev440075';

select * from atgcata.vzw_sor_device_to_accessory where product_id='dev440075';

select * from atgcata.vzw_vendor_device_to_accessory;

select * from atgcore.dcspp_order where order_id='T25779977';

/* Formatted on 4/24/2014 1:25:05 PM (QP5 v5.252.13127.32847) */
SELECT *
  FROM atgcore.dcspp_order a, ATGCORE.VZW_ORDER b
 WHERE a.order_id = 's268238672' AND a.order_id = B.ORDER_ID;
 
 SELECT a.order_id, a.site_id, B.CLIENT_REFERENCE_NUMBER, b.channel_id
  FROM atgcore.dcspp_order a, ATGCORE.VZW_ORDER b
 WHERE a.order_id = 'T25779977' AND a.order_id = B.ORDER_ID;
 
select count(*) 
from atgcore.dcspp_order a, atgcore.vzw_order b
where a.submitted_date > current_date - interval '32' hour
   and a.order_id = b.order_id;
  
select * 
from atgcore.dcspp_order a, atgcore.vzw_order b
where a.submitted_date < current_date - interval '48' hour
   and a.order_id = b.order_id
   and A.SITE_ID = '100002'
   order by a.submitted_date desc;

--a.order_id, a.site_id, B.CLIENT_REFERENCE_NUMBER, b.channel_id

select a.order_id, a.site_id, B.CLIENT_REFERENCE_NUMBER, b.channel_id, A.STATE, A.SUBMITTED_DATE
from atgcore.dcspp_order a, atgcore.vzw_order b
where a.submitted_date > current_date - interval '18' hour
   and a.order_id = B.CLIENT_REFERENCE_NUMBER
   and a.order_id = b.order_id;

select * from atgcore.vzw_site;

select * from atgcore.VZW_CQ_HTML;

select * from atgcore.VZW_CQ_HTML where html_id='2100004';

---------------------------------

select * from atgcore.DPI_RECYCLING_VALUES;

select count(*) from atgcore.DPI_RECYCLING_VALUES;

select count(distinct item_id) from atgcore.dpi_recycling_values;

desc atgcore.DPI_RECYCLING_VALUES;

select * from atgcore.DPI_RECYCLING_DEVICES;

desc atgcore.DPI_RECYCLING_DEVICES;