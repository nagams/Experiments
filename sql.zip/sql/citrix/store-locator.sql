select * from atgcore.vzw_store_locator;

select count(*) from atgcore.vzw_store_locator;

select * from atgcore.vzw_wrk_appt_reference;

select count(*) from atgcore.vzw_wrk_appt_reference;

select * from atgcore.vzw_wrk_appt_eventloc_ref;

select count(*) from atgcore.geoipcity_location;

select count(*) from atgcore.geoipcity_block;

select * from atgcore.vzw_wrk_categories;

select count(*) from atgcore.vzw_store_locator;

SELECT t1.state_id
  FROM atgcore.vzw_state t1
 WHERE state_id=300002;

SELECT t1.state_id
  FROM atgcore.vzw_state t1
 WHERE state_id='NJ';
 
SELECT *
  FROM atgcore.vzw_state t1
 WHERE state_id=300002; 

select * from atgcore.vzw_state;

SELECT t1.retail_id,t1.ADDRESS1,t1.CITY,t1.STATE,t1.ZIP
  FROM atgcore.vzw_store_locator t1
 WHERE ((lower(t1.CITY) LIKE '%07305%')
   OR (lower(t1.STATE_NAME) LIKE '%07305%')
   OR (lower(t1.STATE) LIKE '%07305%')
   OR (lower(t1.ADDRESS1) LIKE '%07305%')
   OR (lower(t1.ZIP) LIKE '%07305%'))
ORDER BY t1.ADDRESS1 ASC, t1.CITY ASC, t1.STATE ASC, t1.ZIP ASC;

----- these below repeate
SELECT t1.retail_id
  FROM atgcore.vzw_store_locator t1
 WHERE (t1.retail_id = 202828);

SELECT t1.id
  FROM atgcore.vzw_wrk_appt_reference t1
 WHERE (t1.EVENT_TYPE = 'APPT');

SELECT t1.id,t1.LANGUAGE_IND,t1.EVENT_TYPE,t1.CATEGORY_NAME,t1.EVENT_SUBTYPE,t1.CATEGORY_CODE,t1.CATEGORY_DESCRIPTION
  FROM atgcore.vzw_wrk_appt_reference t1
 WHERE t1.id IN ('BI','DT','SL');

 SELECT STORE_NUMBER,VERIZON_NUMBER,STORE_NAME,BUSINESS_NAME,STORE_TYPE,AREA,REGION,ADDRESS1,ADDRESS2,CITY,STATE,STATE_NAME,ZIP,ZIP_PLUS,PHONE_NUMBER,FAX_NUMBER,STORE_STATUS,OPENING_DATE,CLOSING_DATE,DIRECT,HOURS_SUN,HOURS_MON,HOURS_TUE,HOURS_WED,HOURS_THU,HOURS_FRI,HOURS_SAT,TECH_HOURS_SUN,TECH_HOURS_MON,TECH_HOURS_TUE,TECH_HOURS_WED,TECH_HOURS_THU,TECH_HOURS_FRI,TECH_HOURS_SAT,SOFTWARE_FLASH,PAYMENTS_ACCEPTED,LATINO_IND_FLAG,DISASTER_IMPACTED,DIS_COMMENTS,TEMPORARY_HOURS,SERVICES_AVAILABLE,PREMIUM_RETAILER,SPECIAL_HOUR_FLAG,SUNDAY_SPECIAL_HOURS_DATE,MONDAY_SPECIAL_HOURS_DATE,TUESDAY_SPECIAL_HOURS_DATE,WEDNESDAY_SPECIAL_HOURS_DATE,THURSDAY_SPECIAL_HOURS_DATE,FRIDAY_SPECIAL_HOURS_DATE,SATURDAY_SPECIAL_HOURS_DATE,FIOS_FLAG,NETWORK_REPEATER,NETACE_LOCATION_CODE,IN_STORE_PICKUP_FLAG,LATITUDE,LONGITUDE,FIPSCODE,ENERGY_STAR_FLAG,LEED_CERTIFIED
   FROM atgcore.vzw_store_locator
  WHERE retail_id=202828;
----- end repeate--------

-- lot of reads for this ---
SELECT t1.id
  FROM atgcore.vzw_wrk_appt_reference t1
 WHERE (t1.EVENT_TYPE = 'APPT');
-------------------------------------

 SELECT t1.id,t1.LANGUAGE_IND,t1.EVENT_TYPE,t1.CATEGORY_NAME,t1.EVENT_SUBTYPE,t1.CATEGORY_CODE,t1.CATEGORY_DESCRIPTION
   FROM atgcore.vzw_wrk_appt_reference t1
  WHERE t1.id IN ('45','46','47','48','49','1242','1280','1400','1440','1442','1480','1482','1520','1560','1562','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','96','97','98','1002','1005','1006','1007','1008','1009','1040','1080','1082','1160','1200','1202','1240','1640','1642','1644','1646','1680','1682','1720','1760','1840','1880','1920','1960','2000','2040','2080','2082','2120','2160','2256','2258','2260','2262','52282','52361','52442','52443','52522','52523','52531','52535','52601','52602','52603','52604','52605','52606','52607','52608','52609','52610');
 
 SELECT t1.id
   FROM atgcore.vzw_wrk_appt_reference t1
  WHERE ((t1.CATEGORY_CODE = 'BBS')
    AND (t1.EVENT_TYPE = 'WRK'));
--APL, WRK, LFS, WRK, SSR, WIN, ANR, TDR, BSL

Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200001', 'WRK', 'ANR', 'Android Operating System', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200002', 'WRK', 'BSL', 'Business Solutions', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200003', 'WRK', 'WIN', 'Windows Operating System', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200004', 'WRK', 'SSR', 'Safety and Security', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200005', 'WRK', 'APL', 'Apple iOS', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200006', 'WRK', 'BBS', 'Blackberry Operating System', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200007', 'WRK', 'TDR', 'Test Drive', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');
Insert into VZW_WRK_CATEGORIES
   (ID, EVENT_TYPE, CATEGORY_CODE, CATEGORY_NAME, CREATED_DATE, 
    CREATED_BY)
 Values
   ('200008', 'WRK', 'LFS', 'Lifestyle', TO_DATE('03/23/2015 11:48:02', 'MM/DD/YYYY HH24:MI:SS'), 
    'WrkAptReferenceDataScheduler');  

commit;