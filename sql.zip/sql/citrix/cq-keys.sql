
select * from atgcore.VZW_CQ_LABEL where content_key like '%PREPAY_REMOVE_ACCESSORY_TXT%';

select * from atgcore.VZW_CQ_HTML where content_key like '%PLAN_CONFIG_DATA%' and site_id='PREPAY';

--PLAN_CONFIG_ADDITIONAL_FEATURES_TABLETS_CONTENT-desktop
--PLAN_CONFIG_CONDITIONS_APPLY_INTERNETDEVICES_CONTENT-desktop
select * from atgcore.VZW_CQ_HTML where content_key like 'PLAN_CONFIG_ADDITIONAL_FEATURES_TABLETS_CONTENT%' and site_id='PREPAY';

select * from atgcore.VZW_CQ_HTML where content_key like 'PREPAY_CART_LEGAL_CONTENT%' and site_id='PREPAY';

select * from atgcore.VZW_CQ_HTML where content_key like 'PLAN_CONFIG_DATA_HEADER%' and site_id='PREPAY';

SELECT html_id, content_key, html_body
  FROM atgcore.VZW_CQ_HTML
 WHERE     content_key LIKE 'PLAN_CONFIG_MORE_INFORMATION_%_CONTENT%'
       AND site_id = 'PREPAY'
       AND device_target = 'desktop';
       
--2.    PLAN_CONFIG_DATA_BASICPHONES_DESCRIPTION        
SELECT html_id, content_key, html_body
  FROM atgcore.VZW_CQ_HTML
 WHERE     content_key LIKE 'PLAN_CONFIG_DATA_%_DESCRIPTION%'
       AND site_id = 'PREPAY'
       AND device_target = 'desktop';


select * from atgcore.VZW_CQ_HTML where content_key like 'CK_PDP_BANNER_IPHONE7_PLUS_TRADE_IN_091416%' and site_id='PREPAY';

select * from atgcore.VZW_CQ_HTML where content_key like 'PLAN_CONFIG_MORE_INFORMATION_%_CONTENT%' and site_id='PREPAY';

select * from atgcore.vzw_cq_label where content_key ='SHIPPING_AUTHORIZATION_MSG-desktop';

SELECT count(*)
  FROM atgcore.VZW_CQ_HTML
 WHERE content_key IN ('PLAN_CONFIG_HEADLINE-DESKTOP',
                       'PLAN_CONFIG_HEADLINE_CONTENT-DESKTOP',
                       'PLAN_CONFIG_SMARTPHONES_DATA_HEADER-DESKTOP',
                       'PLAN_CONFIG_BASICPHONES_DATA_HEADER-DESKTOP',
                       'PLAN_CONFIG_DATA_HEADER-DESKTOP',
                       'PLAN_CONFIG_DATA_SMARTPHONES_DESCRIPTION-DESKTOP',
                       'PLAN_CONFIG_DATA_BASICPHONES_DESCRIPTION-DESKTOP',
                       'PLAN_CONFIG_DATA_DESCRIPTION-DESKTOP',
                       'PLAN_CONFIG_VIEW_PLAN_DETAILS-DESKTOP',
                       'PLAN_CONFIG_HIDE_PLAN_DETAILS-DESKTOP',
                       'PLAN_CONFIG_ADDITIONAL_FEATURES_HEADER-DESKTOP',
                       'PLAN_CONFIG_MORE_INFORMATION-DESKTOP',
                       'PLAN_CONFIG_MORE_INFORMATION_SMARTPHONES_CONTENT-DESKTOP',
                       'PLAN_CONFIG_MORE_INFORMATION_BASICPHONES_CONTENT-DESKTOP',
                       'PLAN_CONFIG_MORE_INFORMATION_DATA_CONTENT-DESKTOP',
                       'PLAN_CONFIG_REASONS_TOGO_HEADER-DESKTOP',
                       'PLAN_CONFIG_REASONS_TOGO_CONTENT-DESKTOP')
                 AND site_id='PREPAY';
                 
SELECT COUNT (*)
  FROM atgcore.VZW_CQ_HTML
 WHERE     content_key IN ('PREPAY_SHIPPING_PROMO_MESSAGE-DESKTOP',
                           'PREPAY_ACTIVATION_FEE_TOOLTIP-DESKTOP',
                           'SAVED_CART_OFFER_AVAILABILITY_TOOL_TIP_MSG-DESKTOP',
                           'SAVED_CART_SUBSCRIBER_NOTIFICATIONS_TOOL_TIP_MSG-DESKTOP',
                           'SAVED_CART_PRIVACY_POLICY_TOOL_TIP_MSG-DESKTOP')
       AND site_id = 'PREPAY';                 

SELECT count(*)
  FROM atgcore.vzw_cq_label
 WHERE     content_key IN ('TOTAL_DUE_LBL-DESKTOP',
                           'DATA_LBL-DESKTOP',
                           'ACCESS_LBL-DESKTOP',
                           'ANYTIME_MINUTES_LBL-DESKTOP',
                           'MEX_CAN_MINUTES_LBL-DESKTOP',
                           'ONE_TIME_ACT_FEE_LBL-DESKTOP',
                           'SUB_TOTAL_LBL-DESKTOP',
                           'ADD_PLAN_TO_CART-DESKTOP',
                           'ORDER_SUMMARY_LBL-DESKTOP',
                           'PER_MONTH_LBL-DESKTOP',
                           'GET_ADD_FEATURES_FOR_YOUR_ACCT-DESKTOP',
                           'ORDER_SUMMARY_NOTE_TEXT-DESKTOP',
                           'PLAN_LBL-DESKTOP')
       AND site_id = 'PREPAY';
       
SELECT COUNT (*)
  FROM atgcore.vzw_cq_label
 WHERE     content_key IN ('CART_MINIRECEIPT_TOTAL_SUMMARY-DESKTOP',
                           'CLEAR_CART_LNK-DESKTOP',
                           'DUE_TODAY-DESKTOP',
                           'MAX_NUM_OF_PRPMO_CODE_LBL-DESKTOP',
                           'NSO_PLAN_CART_SUMMARY_INFO_TXT-DESKTOP')
       AND site_id = 'PREPAY';       
       
SELECT * FROM ATGCORE.VZW_CQ_ERROR WHERE CONTENT_KEY LIKE '%SHOPPINGCART.ERROR.POSTPAYITEMSPRESENTINCART%';

select * from atgcore.vzw_cq_error where content_key like '%ShoppingCart%';
       
SELECT length(a.value), a.* FROM ATGCATA.VZW_TEXT a  
where  
--key like '%%'
key in (
'ShoppingCart.Error.PostpayItemsPresentInCart',
'ShoppingCart.Error.PrepaidItemsPresentInCart'
)