SELECT EVENT.SYSTEM_NAME,
       event.audit_event_type_name,
       ext.round_trip_time,
       ext.order_number,
        --event.audit_event_type_name,
        EVENT.SERVICE_NAME,
        EVENT.SUB_SERVICE_NAME,
        EXT.SOURCE_COMING_FROM,
        EXT.EXTERNAL_SYSTEM_GENERATED_ID correlation_id,
        ext.event_date,
        req.req_data,
        req.res_data
   FROM esAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
         LEFT JOIN esAUDIT.VZW_REQ_RES_HISTORY req
            ON ext.clob_id = req.clob_id
        LEFT JOIN esAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE    
        event_date IS   NOT   NULL
       --AND ext.session_id like  'zyVgU5Hb2ssAOkPCa1pKF7J4diFOWYZgnGndSJTEtFzEUFCBHsbE!605179823!saswcvzczao04%'
       --AND EVENT.AUDIT_EVENT_TYPE_NAME = 'WEB_POS_COMPUTED_OFFERS_SUCCESS'
       AND EXT.EVENT_DATE >= TO_DATE ('22-SEP-16 03.38.00', 'dd-MM-YY hh24.mi.ss')
       --AND EXT.EVENT_DATE <= TO_DATE ('17-FEB-16 04.41.00', 'dd-MM-YY hh24.mi.ss')
       --AND ext.round_trip_time > 3000
       AND EVENT.AUDIT_EVENT_TYPE_NAME IN ( 'RESPONSYS_EMAIL_SERVICE_SUCCESS')
       AND ext.order_number = 's270419320'
ORDER BY ext.event_date DESC;

--ORDER BY EXT.ROUND_TRIP_TIME DESC;

select * from ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY;

select * from ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY order by event_date desc;

select * from ATGAUDIT.VZW_REQ_RES_HISTORY;

select * from ATGAUDIT.VZW_AUDIT_EVENT_TYPE;

select count (*) from (SELECT EVENT.SYSTEM_NAME,
       event.audit_event_type_name,
       ext.round_trip_time,
       ext.order_number,
        --event.audit_event_type_name,
        EVENT.SERVICE_NAME,
        EVENT.SUB_SERVICE_NAME,
        EXT.SOURCE_COMING_FROM,
        EXT.EXTERNAL_SYSTEM_GENERATED_ID correlation_id,
        ext.event_date,
        req.req_data,
        req.res_data
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
         LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
            ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE    
        event_date IS   NOT   NULL
       --AND ext.session_id like  'zyVgU5Hb2ssAOkPCa1pKF7J4diFOWYZgnGndSJTEtFzEUFCBHsbE!605179823!saswcvzczao04%'
       --AND EVENT.AUDIT_EVENT_TYPE_NAME = 'WEB_POS_COMPUTED_OFFERS_SUCCESS'
       AND EXT.EVENT_DATE >= TO_DATE ('12-FEB-16 09.15.00', 'dd-MM-YY hh24.mi.ss')
       AND EXT.EVENT_DATE <= TO_DATE ('12-FEB-16 10.00.00', 'dd-MM-YY hh24.mi.ss')
       --AND ext.round_trip_time > 5000
ORDER BY ext.event_date DESC);

----------
-- LT 1/9: TDC
--  WHERE EXT.EVENT_DATE >= TO_DATE ('08-JAN-15 23.20.00', 'dd-MM-YY hh24.mi.ss')
--    AND EXT.EVENT_DATE <= TO_DATE ('09-JAN-15 00.01.00', 'dd-MM-YY hh24.mi.ss')
-- LT 1/23: TDC
-- '22-JAN-15 21.00.00', 'dd-MM-YY hh24.mi.ss'
-- '22-JAN-15 21.40.00', 'dd-MM-YY hh24.mi.ss'
-- LT 2/5: TDC
--'05-FEB-15 20.55.00', 'dd-MM-YY hh24.mi.ss'
--'05-FEB-15 21.20.00', 'dd-MM-YY hh24.mi.ss'

SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('20-FEB-15 00.05.00', 'dd-MM-YY hh24.mi.ss')
    --AND EXT.EVENT_DATE <= TO_DATE ('05-FEB-15 21.20.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 10000
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'POS_WRITE_ORDER_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'MLS_WEB_POS_WRITE_ORDER_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_GET_QUESTIONS_SERVICE_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'FULL_EVENT_VIEW_BY_LOCATION_TYPE_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_VALIDATE_ANSWERS_SERVICE_SUCCESS'
ORDER BY ext.event_date DESC;

select count(*) from (
SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('29-SEP-15 08.30.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('29-SEP-15 09.10.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 10000
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    AND EVENT.SYSTEM_NAME = 'VISION'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'POS_WRITE_ORDER_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'MLS_WEB_POS_WRITE_ORDER_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_GET_QUESTIONS_SERVICE_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'FULL_EVENT_VIEW_BY_LOCATION_TYPE_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_VALIDATE_ANSWERS_SERVICE_SUCCESS'
ORDER BY ext.event_date DESC);


SELECT  ext.round_trip_time,
        ext.order_number,
        --event.audit_event_type_name,
        system_name,
        EVENT.SERVICE_NAME,
        EVENT.SUB_SERVICE_NAME,
        ext.event_date,
        EXT.EXTERNAL_SYSTEM_GENERATED_ID correlation_id,
        EXT.SESSION_ID
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('29-SEP-15 08.30.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('29-SEP-15 09.10.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 3000
    AND EVENT.SYSTEM_NAME = 'VISION'
ORDER BY ext.event_date DESC;

select SYSTEM_NAME, count(*) from  (
SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number,
        EVENT.SYSTEM_NAME
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('29-SEP-15 08.30.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('29-SEP-15 09.10.00', 'dd-MM-YY hh24.mi.ss')
    --AND EXT.ROUND_TRIP_TIME > 10000
ORDER BY ext.event_date DESC) group by system_name;

SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('18-FEB-15 07.10.19', 'dd-MM-YY hh24.mi.ss')
    --AND EXT.EVENT_DATE <= TO_DATE ('18-FEB-15 .20.19', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 5000
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'POS_WRITE_ORDER_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'MLS_WEB_POS_WRITE_ORDER_SUCCESS'
ORDER BY ext.event_date DESC;


SELECT  ext.round_trip_time,
        event.audit_event_type_name,
        ext.order_number,
        EVENT.SERVICE_NAME,
        EVENT.SUB_SERVICE_NAME,
        EXT.EXTERNAL_SYSTEM_GENERATED_ID correlation_id
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE 
     -- EVENT.AUDIT_EVENT_TYPE_NAME = '%LOC%'
     --EVENT.SYSTEM_NAME = 'POS'
     EVENT.SERVICE_NAME like '%StoreLocatorService%'
ORDER BY ext.event_date DESC;