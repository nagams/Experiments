SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number,
        req.req_data,
        req.res_data,
        ext.session_id
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
         LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
            ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE     event_date IS   NOT   NULL
       AND ext.session_id =  'rYnvJk7TyhQYZyHpyt7hm7jkLTkvQxHcWNhJQrQyH0pL2hVBjGxy!2121256696!cis-eapp12!5164!-1!1415854926047'
ORDER BY ext.event_date DESC;

select * from ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY;

----------
-- LT 1/9: TDC
--  WHERE EXT.EVENT_DATE >= TO_DATE ('08-JAN-15 23.20.00', 'dd-MM-YY hh24.mi.ss')
--    AND EXT.EVENT_DATE <= TO_DATE ('09-JAN-15 00.01.00', 'dd-MM-YY hh24.mi.ss')
-- LT 1/23: TDC
-- '22-JAN-15 21.00.00', 'dd-MM-YY hh24.mi.ss'
-- '22-JAN-15 21.40.00', 'dd-MM-YY hh24.mi.ss'
-- LT 2/5: TDC
--'05-FEB-15 20.55.00', 'dd-MM-YY hh24.mi.ss'
--'05-FEB-15 21.20.00', 'dd-MM-YY hh24.mi.ss'

SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('05-FEB-15 20.55.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('05-FEB-15 21.20.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 10000
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'POS_WRITE_ORDER_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'MLS_WEB_POS_WRITE_ORDER_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_GET_QUESTIONS_SERVICE_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'FULL_EVENT_VIEW_BY_LOCATION_TYPE_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_VALIDATE_ANSWERS_SERVICE_SUCCESS'
ORDER BY ext.event_date DESC;

select count(*) from (
SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('05-FEB-15 20.55.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('05-FEB-15 21.30.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 500
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    AND EVENT.SYSTEM_NAME = 'VISION'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'POS_WRITE_ORDER_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'MLS_WEB_POS_WRITE_ORDER_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_GET_QUESTIONS_SERVICE_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'FULL_EVENT_VIEW_BY_LOCATION_TYPE_SUCCESS'
--    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'WEB_EID_VALIDATE_ANSWERS_SERVICE_SUCCESS'
ORDER BY ext.event_date DESC);


SELECT  ext.round_trip_time,
        ext.order_number,
        EVENT.SERVICE_NAME,
        EVENT.SUB_SERVICE_NAME,
        EXT.EXTERNAL_SYSTEM_GENERATED_ID correlation_id
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('05-FEB-15 20.55.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('05-FEB-15 21.30.00', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 10000
    AND EVENT.SYSTEM_NAME = 'VISION'
ORDER BY ext.event_date DESC;


SELECT event.audit_event_type_name,
        ext.event_date,
        ext.round_trip_time,
        ext.order_number
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EXT.EVENT_DATE >= TO_DATE ('15-JAN-15 10.40.19', 'dd-MM-YY hh24.mi.ss')
    AND EXT.EVENT_DATE <= TO_DATE ('15-JAN-15 11.20.19', 'dd-MM-YY hh24.mi.ss')
    AND EXT.ROUND_TRIP_TIME > 2000
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    --AND EVENT.AUDIT_EVENT_TYPE_NAME like '%VISION%'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'POS_WRITE_ORDER_SUCCESS'
    AND EVENT.AUDIT_EVENT_TYPE_NAME != 'MLS_WEB_POS_WRITE_ORDER_SUCCESS'
ORDER BY ext.event_date DESC;


SELECT  ext.round_trip_time,
        ext.order_number,
        EVENT.SERVICE_NAME,
        EVENT.SUB_SERVICE_NAME,
        EXT.EXTERNAL_SYSTEM_GENERATED_ID correlation_id
   FROM ATGAUDIT.VZW_EXTERNAL_SERVICE_HISTORY ext
       LEFT JOIN ATGAUDIT.VZW_REQ_RES_HISTORY req
           ON ext.clob_id = req.clob_id
        LEFT JOIN ATGAUDIT.VZW_AUDIT_EVENT_TYPE event
            ON event.Audit_event_type_id =   ext.Audit_event_type_id
  WHERE EVENT.AUDIT_EVENT_TYPE_NAME = '%POS%'
    --AND EVENT.SYSTEM_NAME = 'VISION'
ORDER BY ext.event_date DESC;