select * from atgcore.DAS_ID_GENERATOR;

select * from atgcore.DAS_ID_GENERATOR where id_space_name='order';

select * from atgcore.DAS_ID_GENERATOR where id_space_name='price';

select count(*) from atgcore.pos_order_status;

select * from atgcore.pos_order_status where netace_order_num='000270662';

desc atgcore.vzw_order;

desc atgcore.dcspp_order;

select * from atgcore.dps_user;

--my profile, id: ODC22770411
select * from atgcore.dps_user where login='2014923722';
select * from atgcore.vzw_user_global_id where user_id='ODC22770411';

select * from atgcore.dps_user a, ATGCORE.VZW_SSO b where A.ID = B.VZW_USER_ID and B.VZW_MOBILE_NUMBER='2015729422';
--SDC6683135

select * from atgcore.dcspp_order a where A.PROFILE_ID='SDC6683135'; 

select * from atgcore.dcspp_order_rel where order_id='2100294450';

select * from atgcore.dcspp_relationship where relationship_id='SDC276007';

select * from atgcore.dcspp_order a where A.ORDER_ID in ('2104018300', '2103494655', '2103593981', '5101902029', '2103370266', '2103614414', '2100369010', '5102040159', '5102297495', '5102721113', '2100294450', '5102306043', '5102616320', '2100059002');


select * from atgcore.dcs_price_list;

select * from atgcata.vzw_sku where sor_id='SCS-2U01';

select * from atgcata.dcs_product;

select * from atgcata.vzw_sed_offer where SED_id='84717';
select * from atgcata.vzw_sed_offer where SED_id='84718';

select * from atgcata.vzw_sed_offer where SED_id in ('84717', '84718');

select * from atgcatb.vzw_sed_offer where SED_id in ('81929', '84718');
-------------------------------------------------------------------

SELECT a.order_id, a.state, a.creation_date, a.last_modified_date, a.EXPLICITLY_SAVED, c.auto_saved
FROM atgcore.dcspp_order a, atgcore.VZW_ORDER b, atgcore.VZW_ONLINE_ORDER c 
WHERE a.state = 'INCOMPLETE' and
a.order_id = b.order_id and
c.order_id = b.order_id
AND a.profile_id IN (SELECT id
FROM atgcore.dps_user
WHERE login = '2152081913')
ORDER BY a.CREATION_DATE desc;

SELECT  e.login , a.order_id, a.state, a.creation_date, a.last_modified_date, a.EXPLICITLY_SAVED, c.auto_saved,a.PROFILE_ID
  FROM atgcore.dcspp_order a, atgcore.VZW_ORDER b, atgcore.VZW_ONLINE_ORDER c , atgcore.dcspp_item d, atgcore.dps_user e
  WHERE a.state = 'INCOMPLETE' and
  a.order_id = b.order_id and
  c.order_id = b.order_id
  and c.auto_saved = 0
  and d.order_ref = b.order_id 
  and d.site_id = '400001'
  and e.id = a.profile_id
  AND a.profile_id IN (
  select b.id from atgcore.vzw_user a , atgcore.dps_user b where ECPD_PROFILE_ID = 0 and a.user_id = b.id)
  ORDER BY a.CREATION_DATE desc; 
  
select * from atgcore.dcspp_order;  

select * from atgcore.vzw_order;