select * from atgcore.vzw_ship_option_rules where ship_option_unique_id ='FEDEXSHP002'; 

select * from atgcore.vzw_ship_option_rules;

select distinct ship_option_unique_id from atgcore.vzw_ship_option_rules;

select * from geoipcity_block;


select * from geoipcity_location;

--ship_option_unique_id,day_of_week,start_time,end_time
--"FEDEXSHP002:2:01-JAN-14 12.00.00.000000000 AM:01-JAN-14 03.59.00.000000000 PM"

select * from atgcore.vzw_ship_option_rules 
where ship_option_unique_id='FEDEXSHP002'
  and  day_of_week=2
  and  start_time='01-JAN-14 12.00.00.000000000 AM'
  and  end_time='01-JAN-14 03.59.00.000000000 PM';


select * from vzw_ship_option_rules 
where ship_option_unique_id='FEDEXSHP002'
  and  day_of_week=2
  and  start_time='01-JAN-14 12.00.00.000000000 AM';

desc vzw_ship_option_rules;   


/* Formatted on 6/19/2015 4:22:21 PM (QP5 v5.252.13127.32867) */
SELECT ship_option_unique_id,
       day_of_week,
       start_time,
       end_time
  FROM vzw_ship_option_rules
 WHERE     ship_option_unique_id = ?
       AND day_of_week = ?
       AND (? BETWEEN TO_CHAR (start_time, 'HH24:MI')
                  AND TO_CHAR (end_time, 'HH24:MI'));
                  
--sddFDDshippingOptionsSQL= 

/* Formatted on 6/22/2015 12:14:57 PM (QP5 v5.252.13127.32867) */
SELECT ship_option_unique_id,
       day_of_week,
       start_time,
       end_time
  FROM vzw_ship_option_rules
 WHERE     (   ship_option_unique_id = 'shipOptionValue1'
            OR ship_option_unique_id = 'shipOptionValue2')
       AND day_of_week = 'dayOfWeekValue'
       AND ('currentTimeValue' BETWEEN TO_CHAR (start_time, 'HH24:MI')
                                   AND TO_CHAR (end_time, 'HH24:MI'))                  