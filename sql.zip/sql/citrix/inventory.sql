SELECT * FROM atgcore.dcs_inventory;
  
SELECT * FROM atgcore.item_availability where sku='BB9370';

SELECT * FROM atgcore.item_availability where sku='SCHI435ZKV';

SELECT * FROM atgcore.item_availability where sku like '%MGFG2LL%';
  
SELECT * FROM atgcore.items_fulfillment_status where sku like '%MGFG2LL%';

SELECT * FROM atgcore.items_fulfillment_status where availability_flow='B';

SELECT * FROM atgcore.items_fulfillment_status where availability_flow = 'P';

SELECT * FROM atgcore.items_fulfillment_status where availability_flow = 'P' and device_type='D';

/* Formatted on 3/5/2015 11:50:10 AM (QP5 v5.252.13127.32867) */
INSERT INTO atgcore.items_fulfillment_status (SKU,
                                              DEVICE_TYPE,
                                              EXP_SHIP_DATE,
                                              AVAILABILITY_FLOW,
                                              AVAILABLE)
     VALUES ('MGFG2LL/A',
             'D',
             '3/20/2015',
             'P',
             'Y');
             
--sku1200149 iphone5c
--SCHI435ZKV gmini

select * from atgcata.vzw_sku where sor_id like 'SCHI545PKVPS';

/* Formatted on 3/4/2015 2:26:02 PM (QP5 v5.252.13127.32867) */
SELECT A.SKU,
       B.PROD_NAME,
       C.DEVICE_TYPE,
       A.QTY_AVAILABLE,
       C.AVAILABILITY_FLOW,
       C.AVAILABLE,
       C.EXP_SHIP_DATE,
       A.MODIFIED_DATE,
       B.SEO_URL_NAME,
       A.LOCATION_CODE
  FROM atgcore.item_availability a, atgcata.vzw_sku b, atgcore.items_fulfillment_status c
 WHERE A.SKU = B.SOR_ID 
   AND A.SKU = C.SKU
   AND A.SKU = 'SCHI435ZKV';
   

   