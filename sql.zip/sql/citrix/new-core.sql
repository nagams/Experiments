select * from ATGCORE_ltcom.DAS_ID_GENERATOR;

select count(*) from atgcore_ltcom.dcspp_order;

select * from atgcore_ltcom.dcspp_order;

select * from atgcore_ltcom.vzw_http_props;

select * from atgcore.vzw_http_props;

select * from atgcore.COMPATIBLE_SFO;

select * from atgcore.VZW_CONDITION_SFO_TO_RULE;

select * from atgcore.COMPATIBLE_PLAN;

select * from atgcore.VZW_CONDITION_PLAN_TO_RULE;

select * from atgcore.outlet;

select * from atgcore.vzw_dacc_equip;

select * from atgcore.vzw_dacc_to_equip_code;

select * from atgcore.vzw_plan_cap;

select * from atgcore.vzw_plan_cap_to_dacc;

select * from atgcore.VISION_COMPATIBLE_PLAN_FEED;

select * from atgcore.VISION_COMPATIBLE_SFO_FEED;

select * from atgcore.DAS_GROUP_ASSOC;

select * from atgcore.DAS_GSA_SUBSCRIBER;

select * from atgcore.das_sds;

select * from atgcore.DAS_SECURE_ID_GEN;

select * from atgcore.DMS_CLIENT;

select * from atgcore.DMS_LIMBO;


SELECT a.site_id,  count(*)
  FROM atgcore.dcspp_order a
 WHERE a.state = 'INCOMPLETE'
   AND a.order_id not in (SELECT order_id FROM atgcore.dcspp_order_rel)
   --AND a.creation_date >= to_char(sysdate-30,'DD/MON/YY')
   group by a.site_id;

SELECT a.site_id,  A.PROFILE_ID, count(*)
  FROM atgcore.dcspp_order a
 WHERE a.state = 'INCOMPLETE'
   AND a.order_id not in (SELECT order_id FROM atgcore.dcspp_order_rel)
   --AND a.creation_date >= to_char(sysdate-30,'DD/MON/YY')
   group by a.site_id, a.profile_id;
   
SELECT a.order_id, a.state, a.creation_date
  FROM atgcore.dcspp_order a
 WHERE a.state = 'INCOMPLETE'
   AND a.profile_id IN (SELECT id
                          FROM atgcore.dps_user
                         WHERE login = '5419990768')
ORDER BY a.CREATION_DATE desc;   

--4102079824
select * from atgcore.dps_user a where A.ID='SDC13720596';