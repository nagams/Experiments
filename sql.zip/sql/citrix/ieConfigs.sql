select * from atgcore.vzw_internal_props where prop_name like '%REDIRECT_TYPES_FOR_SEO_URL%';

--SITE_IDS_FOR_SEO_URL
select * from atgcore.vzw_internal_props where prop_name like '%SITE_IDS_FOR_SEO_URL%';

select * from atgcore.vzw_site_internal_props;

select * from atgcore.vzw_ext_props where prop_name='POSTPAID_EXT_BAZAAR_VOICE_JS_URL';

select * from ATGCORE.VZW_SITE_EXT_PROPS where external_config_id='100017';

select * from ATGCORE.VZW_SITE_EXT_PROPS where external_config_id='100017';

SELECT *
  FROM atgcore.vzw_ext_props
 WHERE external_config_id = '100017';


SELECT *
  FROM atgcore.vzw_ext_props
 WHERE external_config_id IN (SELECT external_config_id
                                FROM ATGCORE.VZW_SITE_EXT_PROPS
                               WHERE id = '100017');

--insert into atgcore.vzw_site_ext_props(external_config_id, id) values('100017','100002');

select * from atgcore.vzw_internal_props where prop_name like 'PREPAID_SEO_302_REDIRECT_FLAG';

--------------------------------------------------------------------------------------------------------
--TDC: Need it for both sites, SDC,ODC: no change
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'HEADLESS_DEALS_LANDING_PAGES_LIST'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;

--TDC=true, ODC,SDC=false
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'PREPAID_LOWERFUNNEL_REDESIGN_ENABLED'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;

--TDC=N, ODC,SDC=Y
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'NSO_PREPAID_EXPRESS_CHECKOUT_KILL_SWITCH'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;

--TDC=Y, ODC,SDC=Y
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'NSO_PREPAID_4G_ACCESSORY_TOOLKIT_KILL_SWITCH'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;

--TDC=Y, ODC,SDC=N
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'PREPAY_TOUCH_COMMERCE_KILL_SWITCH'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;


--TDC=AUTO301:301,AUTO302:302, ODC,SDC=AUTO301:301
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'REDIRECT_TYPES_FOR_SEO_URL'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;

--TDC:need it for Prepay ODC,SDC=don't care much
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_internal_props b, atgcore.vzw_internal_props a
 WHERE     a.prop_name = 'S7_VIDEO_KILLSWITCH'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;


--TDC:need it for Prepay ODC,SDC=don't care much
SELECT a.external_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_ext_props b, atgcore.vzw_ext_props a
 WHERE     a.prop_name = 'PREPAY_EXPRESS_CHECKOUT_ENABLE'
       AND A.EXTERNAL_CONFIG_ID = B.EXTERNAL_CONFIG_ID;

------------------------------------------------------------------------------

SELECT *
  FROM atgcore.vzw_site_internal_props
 WHERE internal_config_id IN (SELECT internal_config_id
                                FROM atgcore.vzw_internal_props
                               WHERE prop_name =
                                        'PREPAID_SEO_302_REDIRECT_FLAG');
                                        
SELECT a.internal_config_id,
       a.prop_name,
       a.prop_value,
       b.id
  FROM atgcore.vzw_site_ext_props b, atgcore.vzw_ext_props a
 WHERE     a.prop_name = 'PREPAY_TOUCH_COMMERCE_KILL_SWITCH'
       AND A.INTERNAL_CONFIG_ID = B.INTERNAL_CONFIG_ID;
                                        