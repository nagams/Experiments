select * from atgcore.dcspp_order a where A.PROFILE_ID='SDC6683135'; 

select * from atgcore.dcspp_order a where A.PROFILE_ID='ODC59745690'; 

--5102297495
select * from atgcore.dcspp_order a where A.ORDER_ID='S1427527546';

select * from atgcore.dps_user where id='ODC59745690';

select * from atgcore.dcspp_order_rel where order_id='2100294450';

select * from atgcore.dcspp_order_rel where order_id='5102297495';

select * from atgcore.dcspp_relationship where order_ref='2100294450';

select * from atgcore.dcspp_relationship where order_ref='5102297495';

--SDC276007  SDC276008
select * from atgcore.dcspp_relationship where relationship_id='SDC276008';

select * from ATGCORE.DCSPP_PAYORDER_REL where relationship_id='SDC276007';

select * from ATGCORE.DCSPP_REL_ORDERS;

select * from atgcore.dcspp_shipitem_rel;


SELECT * FROM atgcore.dcspp_order_rel
                           WHERE relationships NOT IN
                                    (SELECT relationship_id
                                       FROM atgcore.dcspp_relationship);

/* Formatted on 11/25/2013 3:22:35 PM (QP5 v5.252.13127.32847) */
SELECT *
  FROM atgcore.dcspp_order
 WHERE     order_id IN (SELECT order_id
                          FROM atgcore.dcspp_order_rel
                         WHERE relationships NOT IN (SELECT relationship_id
                                                       FROM atgcore.dcspp_relationship))
       AND state = 'INCOMPLETE'
       AND profile_id = 'corrupt-order';
       

select * from atgcata.dcs_price_list;

select * from atgcatb.dcs_price_list;

select count(*) from atgcata.dcs_price; --8153

select count(*) from atgcatb.dcs_price; --8096

select * from atgcatb.dcs_price;

--p20059  p20008

select * from atgcata.dcs_price where price_id='p20008';

select * from atgcata.dcs_price where price_id like 'p%';

select count(*) from atgcata.dcs_price where price_id like 'FRP%';

--
select * from atgcatb.dcs_price where price_id='FRPsku43011';

select * from atgcatb.dcs_sku where sku_id='sku43011';

select * from atgcata.dcs_price_list;

select * from atgcata.dcs_price where sku_id='sku420208';

select * from atgcatb.dcs_price where sku_id in ('sku130156','sku130157','sku130158');

select * from atgcata.dcs_sku where sku_id in  ('sku130156','sku130157','sku130158');

--select 
--fullRetailPriceListId
--cata 4762
--4707
select count(*) from atgcatb.dcs_price where price_list='fullRetailPriceListId';

--catb 4705
--3804
--4764

--cata 4664
--catb 4707
-- 43
select count(*) from atgcata.dcs_price where price_list='fullRetailPriceListId';

select count(*) from atgcatb.dcs_price where price_list='fullRetailPriceListId';


select count(*) from atgcata.dcs_price dprice, atgcata.dcs_sku dsku where dsku.sku_id = dprice.sku_id and dsku.sku_type = '4005' and price_id like 'p_%';

select count(*) from atgcata.dcs_price dprice where dprice.sku_id is null and price_id like 'p_%';

select count(*) from atgcatb.dcs_sku where sku_type='4007';

select * from ATGCORE.DCSPP_ORDER_item;

--Query to fetch UnSubmitted orders where employee discount > 0 
select to_char(t2.creation_date,'DD/MON/YY'), count(*)
from ATGCORE.vzw_order t1, ATGCORE.DCSPP_ORDER t2, ATGCORE.vzw_sso t3, ATGCORE.vzw_order_price t4 where t1.order_id in 
(select order_id from ATGCORE.DCSPP_ORDER 
where creation_site_id ='200001' and order_id in (select order_id from ATGCORE.DCSPP_ORDER_item) and 
creation_date >= to_char(sysdate-7,'DD/MON/YY') and 
state='INCOMPLETE')
AND t1.order_id = t2.order_id
and t3.vzw_user_id = t2.profile_id
AND t4.employee_discount IS NOT NULL
AND t4.amount_info_id = t2.price_info
AND t3.vzw_ecpd_id IS NOT NULL
AND t4.employee_discount > 0
group by to_char(t2.creation_date,'DD/MON/YY')
ORDER BY to_char(t2.creation_date,'DD/MON/YY'); 

select *
from ATGCORE.vzw_order t1, ATGCORE.DCSPP_ORDER t2, ATGCORE.vzw_sso t3, ATGCORE.vzw_order_price t4 where t1.order_id in 
(select order_id from ATGCORE.DCSPP_ORDER 
where creation_site_id ='200001' and order_id in (select order_id from ATGCORE.DCSPP_ORDER_item) and 
creation_date >= to_char(sysdate-7,'DD/MON/YY') and 
state='INCOMPLETE')
AND t1.order_id = t2.order_id
and t3.vzw_user_id = t2.profile_id
AND t4.employee_discount IS NOT NULL
AND t4.amount_info_id = t2.price_info
AND t3.vzw_ecpd_id IS NOT NULL
AND t4.employee_discount > 0;

select * from ATGCORE.vzw_sso;

select * from ATGCORE.vzw_order_price;

SELECT *
  FROM atgcore.dcs_inventory;
  
SELECT *  FROM atgcore.item_availability where sku='SCS-2U01';
  
SELECT * FROM atgcore.items_fulfillment_status where sku='SCS-2U01';

--
SELECT *  FROM atgcore.item_availability where sku='OCPOMOTMZ61716';
  
SELECT * FROM atgcore.items_fulfillment_status where sku='OCPOMOTMZ61716';

SELECT * FROM atgcore.items_fulfillment_status where availability_flow='S';

SELECT * FROM atgcore.item_availability where sku='F7N063B1C04-TL';

SELECT * FROM atgcore.items_fulfillment_status where sku='F7N063B1C04-TL';

select * from atgcore.dcspp_order;
select * from atgcore.dcspp_order_sg where order_id='5105269411';
select * from atgcore.pos_order_status;
select * from atgcore.pos_order_status where netace_order_num='872850' and location_code='D107701'; --5101775537
select * from atgcore.vzw_ship_grp_srv_resp;
--ODC1775538
select * from atgcore.vzw_ship_grp_srv_resp where shipping_group_id='ODC1775538';
select * from atgcore.vzw_order where pos_order_number='872850';
--5101775537
select * from atgcore.dcspp_order where order_id='5101775537';


select * from atgcore.ATG_SKU_OFFER_DTL;
select * from atgcore.ATG_BAGX_OFFER;
select * from atgcore.ATG_BARCODE_OFFER;
select * from atgcore.ATG_REBATE;
select * from atgcore.ATG_SKU_OFFER_MASTER;
select * from atgcore.ATG_TOOLKIT_OFFER;

---02/20/15
select a.order_id, 
       a.profile_id, 
       a.state, 
       a.creation_date, 
       a.last_modified_date, 
       a.site_id 
  from atgcore.dcspp_order a, atgcore.dps_user b 
 where A.ORDER_ID in ('S1427527546','S1424527709','S1423927722','S1426227585','S1426127577','S1427727554','S1423027736','S1427027578','S1426027595','S1424727734','S1427327578','S1427227584','S1426627610','S1426127605','S1427527546','S1424527709','S1423927722','S1426227585','S1426127577','S1427727554','S1423027736','S1427027578','S1426027595','S1424727734','S1427327578','S1427227584','S1426627610','S1426127605','S1426127772','S1426127771','S1427827744','S1425127892','S1426327777','S1426527787','S1426327778','S1426627775','S1426327780','S1422827940','S1426927785','S1424327906','S1423527954','S1423127931','S1422727949','S1423427934','S1425027896','S1425027895','S1426727786','S1427027765','S1427727746','S1427227751','S1427227752','S1427727747','S1424527917','S1426627776','S1427627746','S1427627747','S1424227923','S1427427755','S1424127934','S1424527919','S1427127768','S1423827923','S1423827924','S1426027776','S1426127775','S1424027940','S1427727748','S1426427787','S1427427756','S1427327749','S1427327750','S1425027899','S1426827780','S1427327751','S1427727749','S1427227754','S1427227755');

select do.order_id,
       du.id OWNER,
       do.last_modified_date,
       do.creation_date,
       do.version,
       do.creation_site_id,
       do.site_id, 
       di.commerce_item_id,
       DI.CATALOG_REF_ID,
       DI.PRODUCT_ID,
       DI.QUANTITY,
       SG.SHIPPING_GROUP_ID,
       SG.SHIPPING_METHOD
from atgcore.dcspp_order do
  left join atgcore.dps_user du on (du.ID = do.profile_id)
  left join atgcore.vzw_sso vu on (vu.vzw_user_id = du.id)
  left join atgcore.dcspp_item di on (di.order_ref = do.order_id)
  left join atgcore.dcspp_ship_group sg on (SG.ORDER_REF = do.order_id)
--where id = 'ODC15717841'
where order_id  in ('S1427527546','S1424527709','S1423927722','S1426227585','S1426127577','S1427727554','S1423027736','S1427027578','S1426027595','S1424727734','S1427327578','S1427227584','S1426627610','S1426127605','S1427527546','S1424527709','S1423927722','S1426227585','S1426127577','S1427727554','S1423027736','S1427027578','S1426027595','S1424727734','S1427327578','S1427227584','S1426627610','S1426127605','S1426127772','S1426127771','S1427827744','S1425127892','S1426327777','S1426527787','S1426327778','S1426627775','S1426327780','S1422827940','S1426927785','S1424327906','S1423527954','S1423127931','S1422727949','S1423427934','S1425027896','S1425027895','S1426727786','S1427027765','S1427727746','S1427227751','S1427227752','S1427727747','S1424527917','S1426627776','S1427627746','S1427627747','S1424227923','S1427427755','S1424127934','S1424527919','S1427127768','S1423827923','S1423827924','S1426027776','S1426127775','S1424027940','S1427727748','S1426427787','S1427427756','S1427327749','S1427327750','S1425027899','S1426827780','S1427327751','S1427727749','S1427227754','S1427227755')
--where id in ('1730067', '740158')
--where id = 'SDC1383469792'
  --and  do.state = 'INCOMPLETE'
  --and vzw_mobile_number = '5182581176'
order by do.last_modified_date desc;

--SDC646559136 SDC647859088 SDC646659079
select * from atgcore.dcspp_shipitem_rel where commerce_item_id in ('SDC646559136', 'SDC647859088', 'SDC646659079');

select * from atgcore.dcspp_ship_group where order_ref='S1427527546';