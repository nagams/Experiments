--==================Trade In========
-- count: 5674
select * from atgcore.device_trade_info_feed;
desc atgcore.device_trade_info_feed;

--count: 170 view
select * from atgcore.device_trade_manufacture;
desc atgcore.device_trade_manufacture;

-- count: 18585
select * from atgcore.device_trade_info;
desc atgcore.device_trade_info;

--count: 134794
select * from atgcore.device_question_answer;
desc atgcore.device_question_answer;

desc pos_order_status;

Select *from atgcore.device_trade_info_feed where erc_model like '%5S%';