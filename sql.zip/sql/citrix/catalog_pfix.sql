select * from atgcata.vzw_sku where sor_id like 'MGCL2LL/A';

select * from atgcata.vzw_sku_plan;

select  * from atgcata.vzw_prd_bundle;

select  * from atgcata.vzw_prd_bundle_phones;

select * from atgcata.dcs_product where product_id in (select  product_id from atgcata.vzw_prd_bundle);

 SELECT sequence_num,sku_link_id
   FROM atgcata.dcs_sku_bndllnk
  WHERE sku_id='sku1200610' ORDER BY 1 ASC

/* Formatted on 10/26/2015 10:12:20 AM (QP5 v5.252.13127.32867) */
SELECT *
  FROM catalogb.vzw_internal_props
 WHERE prop_name IN ('ENABLE_PROMOS_FOR_PAGE_LOAD',
                     'CONCURRENT_PROMOS_IMPACTED_BY_PRICEPLAN_CHANGE',
                     'ENABLE_PROMOS_IMPACTED_BY_PRICEPLAN_CHANGE_API',
                     'ENABLE_SELECTED_PLAN_AJAX_PROMOS_IMPACTED_CALL');

--CIS_ORDER_ID_GENERATOR_KILL_SWITCH                      
select * from atgcatb.vzw_internal_props where prop_name = 'CIS_ORDER_ID_GENERATOR_KILL_SWITCH';

select * from cataloga.vzw_site_internal_props where id='400001' and internal_config_id in ('6100001','9299086','6000011','9299085') ;

select * from catalogb.vzw_site_internal_props where id='400001' and internal_config_id in ('7800002') ;

--catalog40002 prepaid site
select * from atgcata_pfix.dcs_catalog;

select * from atgcata_pfix.dcs_root_cats;

select * from atgcata_pfix.dcs_root_cats where catalog_id='catalog40002';

select count(*) from atgcata_pfix.dcs_category;

select * from atgcata_pfix.dcs_category where display_name like '%martphones%';

select * from atgcata_ptst.vzw_category;

select * from atgcata_ptst.vzw_category where category_id='cat1120003';

--cat1120003
SELECT *
  FROM atgcata_pfix.dcs_category a, atgcata_pfix.vzw_category b
 WHERE display_name LIKE '%martphones%' AND A.CATEGORY_ID = B.CATEGORY_ID; 
 
select * from atgcata.dcs_root_subcats; 

select * from atgcata.dcs_cat_subcats;

select * from atgcata.dcs_product;

SELECT * FROM atgcata.dcs_prd_catalogs;

SELECT COUNT (*)
  FROM atgcata_pfix.dcs_prd_catalogs
 WHERE catalog_id = 'cat1150001';

SELECT * FROM atgcata.dcs_cat_chldprd;

SELECT COUNT (*)
  FROM atgcata.dcs_cat_chldprd
 WHERE category_id = 'cat1120003';
 
SELECT *
  FROM atgcata.dcs_cat_chldprd
 WHERE category_id = 'cat1120003';

-- Prepaid smartphones products
SELECT count(*)
  FROM atgcata_pfix.dcs_product
 WHERE product_id IN (SELECT child_prd_id
                        FROM atgcata_pfix.dcs_cat_chldprd
                       WHERE category_id = 'cat1150001');

SELECT *
  FROM atgcata.dcs_product
 WHERE product_id='dev5480060';
 
----------------

select * from vzw_zip_market where zip_code='07059';
select * from vzw_market where market_id='153';
select * from vzw_warehouse_accessory_sku where accessory_id='49662';
SELECT * FROM VZW_WAREHOUSE_ACCESSORY_SKU WHERE SKU='F8M511TTC00';
desc DCS_PRD_DEVACCES;

DESC DCS_PRODUCT;
DESC DCS_PRODUCT_MAS;
DESC DCS_PRODUCT_DEVICE;
DESC DCS_MEDIA;
DESC DCS_MEDIA_EXT;
desc dcs_sku;
DESC DCS_SKU_MAS; 
DESC DCS_PRD_DEVACCES;

SELECT COUNT(*) FROM DCS_PRODUCT;
SELECT COUNT(*) FROM DCS_PRODUCT WHERE PRODUCT_TYPE=100;
SELECT COUNT(*) FROM DCS_PRODUCT_DEVICE;
SELECT count(*) FROM DCS_PRODUCT_ACCESSORY;

SELECT * FROM DCS_PRODUCT;
SELECT * FROM DCS_PRODUCT where PRODUCT_TYPE=101;
SELECT * FROM DCS_PRODUCT_DEVICE;
SELECT * FROM DCS_PRODUCT_ACCESSORY;

SELECT * FROM DCS_PRODUCT WHERE PRODUCT_ID='ac13471';
select * from dcs_product_mas where wms_product_id='6431';
SELECT * FROM DCS_SKU;
SELECT * FROM DCS_SKU DS, DCS_SKU_MAS MS WHERE DS.SKU_ID = MS.SKU_ID and MS.SKU_CODE = 'F8M511TTC00';
SELECT * FROM DCS_SKU DS, DCS_SKU_MAS MS WHERE DS.SKU_ID = MS.SKU_ID;
select * from dcs_prd_chldsku;
SELECT * FROM DCS_PRD_CHLDSKU WHERE SKU_ID='sku30316';
select * from dcs_media where MEDIA_ID='mini5594';

select * from vzw_dcs_sku_id_mapping where sku_id='sku30316';

SELECT * FROM VZW_DCS_SKU_ID_MAPPING;
DESC VZW_DCS_SKU_ID_MAPPING;

SELECT * FROM VZW_DCS_SKU_ID_MAPPING WHERE SKU_ID='sku30316';
select * from vzw_warehouse_accessory_sku where accessory_id='49662';
--52352
--49662
SELECT * FROM VZW_DCS_SKU_ID_MAPPING WHERE MAS_SKU_ID='52352'; 
--sku31249

desc vzw_warehouse_accessory_sku;

SELECT * FROM VZW_DCS_PRODUCT_ID_MAPPING;
DESC VZW_DCS_PRODUCT_ID_MAPPING;
SELECT * FROM DCS_PRD_MEDIA;
SELECT * FROM VZW_PROD_MEDIA;
SELECT * FROM DCS_INVENTORY;
SELECT COUNT(*) FROM VZW_DEVICE_ACCESSORY_COMPAT;
SELECT * FROM VZW_DEVICE_ACCESSORY_COMPAT;
SELECT COUNT(*) FROM VZW_ACCESSORY_DEVICE_COMPAT;


SELECT * FROM VZW_ACCESSORY_REVIEWS;
alter table crs_bill_codes drop constraint CRS_BILL_CODES_F;

ALTER TABLE DCS_PRD_DEVACCES DROP CONSTRAINT SYS_C0016271;

ALTER TABLE CRS_SHIP_CODES DROP CONSTRAINT CRS_SHIP_CODES_F;
SELECT * FROM CRS_CATALOG;
ALTER TABLE CRS_CATALOG DROP CONSTRAINT CRS_CATALOG_F;

SELECT * FROM DCS_SKU_MAS;
SELECT * FROM DCS_SKU_MAS WHERE SKU_CODE is not null;

desc dcs_media;



SELECT owner, table_name
  FROM ALL_CONSTRAINTS
 WHERE constraint_name = 'SYS_C0016281';

SELECT * FROM DCS_PRICE;
SELECT * FROM DCS_PRICE WHERE LIST_PRICE=0;
SELECT * FROM DCS_PRD_CHLDSKU WHERE PRODUCT_ID='acc40065';
SELECT * FROM DCS_PRICE WHERE SKU_ID IN (SELECT SKU_ID FROM DCS_PRD_CHLDSKU WHERE PRODUCT_ID='acc40065');


---------------------------

