select * from ATGCATA.DCS_PRICE A
where   (a.price_list  in ('fullRetailPriceListId','prepayPriceListId') OR  a.price_list  in ( select 'PP_'|| trim(b2c_net_ace_location) from atgcata.vzw_market))
  and sku_id in ('sku1470017','sku1860174')
order by 4;


select * from ATGCATA.DCS_PRICE A
where   (  a.price_list  in ( select 'PP_'|| trim(b2c_net_ace_location) from atgcata.vzw_market))
order by 4;

select * from ATGCATA.DCS_PRICE A
where   (a.price_list  in ('prepayPriceListId') OR  a.price_list  in ( 'PP_X473601', 'PP_0862001'))
  and sku_id in ('Sku1470017','sku1610076', 'sku1230502', 'sku1110383')
order by 4;


select * from ATGCATA_SQA3.DCS_PRICE A
where   (a.price_list  in ( 'PP_X473601', 'PP_0862001'))
  and sku_id in ('Sku1470017','sku1610076', 'sku1230502', 'sku1110383')
order by 4;