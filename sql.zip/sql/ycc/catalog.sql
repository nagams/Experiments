SELECT value FROM NLS_DATABASE_PARAMETERS WHERE parameter='NLS_CHARACTERSET';
select value from system where parameter='nls_length_semantics';
SELECT value FROM NLS_DATABASE_PARAMETERs WHERE parameter='NLS_LENGTH_SEMANTICS';
show parameter nls_length_semantics;
select * from v$nls_parameters where Parameter = 'NLS_LENGTH_SEMANTICS';
select * from atgcata.dcs_price;

select distinct price_list from atgcata.dcs_price;

select * from ATGCATA.DCS_PRICE_LIST;

select * from cata.yc_sku;
select * from cata.yc_sku where sku_id='1164028';
select count(*) from cata.yc_sku;
desc cata.yc_sku;
desc cata.dcs_sku;
desc cata.YC_SKU_XLATE;
desc cata.dcs_product;
select count(*) from cata.dcs_sku;
select * from catb.YC_SKU_TEMP;
select * from cata.YC_SKU_XLATE;

select * from atgcata.vzw_sku_plan;

select A.MOST_POPULAR_FLAG from atgcata.vzw_sku_plan a where A.MOST_POPULAR_FLAG is not null;

select A.* from atgcata.vzw_sku_plan a where A.MOST_POPULAR_FLAG='1';

--plan2680002
select a.PREPAY_DATA_ALLOWANCE from ATGCATA.VZW_SKU_PLAN a where a.sku_id='sku1810004';

select  * from atgcata.vzw_prd_bundle;

select  * from atgcata.vzw_prd_bundle_phones;

select * from atgcata.dcs_product where product_id in (select  product_id from atgcata.vzw_prd_bundle);

 SELECT sequence_num,sku_link_id
   FROM atgcata.dcs_sku_bndllnk
  WHERE sku_id='sku1200610' ORDER BY 1 ASC

/* Formatted on 10/26/2015 10:12:20 AM (QP5 v5.252.13127.32867) */
SELECT *
  FROM catalogb.vzw_internal_props
 WHERE prop_name IN ('ENABLE_PROMOS_FOR_PAGE_LOAD',
                     'CONCURRENT_PROMOS_IMPACTED_BY_PRICEPLAN_CHANGE',
                     'ENABLE_PROMOS_IMPACTED_BY_PRICEPLAN_CHANGE_API',
                     'ENABLE_SELECTED_PLAN_AJAX_PROMOS_IMPACTED_CALL');

--CIS_ORDER_ID_GENERATOR_KILL_SWITCH                      
select * from atgcatb.vzw_internal_props where prop_name = 'CIS_ORDER_ID_GENERATOR_KILL_SWITCH';

select * from ATGCATA.VZW_EXT_PROPS where prop_name = 'POSTPAID_EXT_BAZAAR_VOICE_JS_URL';

--catalog40002 prepaid site
select * from cata.dcs_catalog;

select * from cata.dcs_root_cats;

select * from atgcata.dcs_root_cats where catalog_id='catalog40002';

select * from cata.dcs_category;

select * from cata.dcs_category where display_name like '%martphones%';

select * from cata.yc_category;

select * from cata.yc_category where category_id='cat1120003';


SELECT *
  FROM atgcata.dcs_category a, atgcata.vzw_category b
 WHERE display_name LIKE '%martphones%' AND A.CATEGORY_ID = B.CATEGORY_ID; 

-- testman, Prepaid Devices - cat120002
SELECT *
  FROM atgcata.dcs_category a, atgcata.vzw_category b
 WHERE A.CATEGORY_ID = 'cat120002' AND A.CATEGORY_ID = B.CATEGORY_ID; 
 
select * from atgcata.dcs_root_subcats; 

select * from atgcata.dcs_cat_subcats;

select * from atgcata.dcs_product;

SELECT a.product_id, a.display_name, B.CANONICAL_URL
  FROM atgcata.dcs_product a, atgcata.vzw_product b
 WHERE a.product_id = B.PRODUCT_ID
   AND a.product_id = 'dev3240025';
   
   --AND B.SEO_URL_NAME = 'samsung-galaxy-note-5-prepaid';

SELECT * FROM atgcata.dcs_prd_catalogs;

select * from atgcata.dcs_catfol_chld;

select * from atgcata.dcs_cat_chldcat;

SELECT sequence_num, child_cat_id
  FROM atgcata.dcs_cat_chldcat
 WHERE category_id = 'cat120002';
 
SELECT COUNT (*)
  FROM atgcata.dcs_prd_catalogs
 WHERE catalog_id = 'catalog40002';

SELECT * FROM atgcata.dcs_cat_chldprd;

SELECT COUNT (*)
  FROM atgcata.dcs_cat_chldprd
 WHERE category_id = 'cat1200005';
 
SELECT *
  FROM atgcata.dcs_cat_chldprd
 WHERE category_id = 'cat1200005';

-- Prepaid smartphones products
SELECT *
  FROM atgcata.dcs_product
 WHERE product_id IN (SELECT child_prd_id
                        FROM atgcata.dcs_cat_chldprd
                       WHERE category_id = 'cat1120003');

SELECT *
  FROM atgcata.dcs_product
 WHERE product_id='dev5480060';
 
----------------

select * from vzw_zip_market where zip_code='07059';
select * from vzw_market where market_id='153';
select * from vzw_warehouse_accessory_sku where accessory_id='49662';
SELECT * FROM VZW_WAREHOUSE_ACCESSORY_SKU WHERE SKU='F8M511TTC00';
desc DCS_PRD_DEVACCES;

DESC DCS_PRODUCT;
DESC DCS_PRODUCT_MAS;
DESC DCS_PRODUCT_DEVICE;
DESC DCS_MEDIA;
DESC DCS_MEDIA_EXT;
desc dcs_sku;
DESC DCS_SKU_MAS; 
DESC DCS_PRD_DEVACCES;

SELECT COUNT(*) FROM cata.DCS_PRODUCT;
SELECT COUNT(*) FROM DCS_PRODUCT WHERE PRODUCT_TYPE=100;
SELECT COUNT(*) FROM DCS_PRODUCT_DEVICE;
SELECT count(*) FROM DCS_PRODUCT_ACCESSORY;

SELECT * FROM DCS_PRODUCT;
SELECT * FROM DCS_PRODUCT where PRODUCT_TYPE=101;
SELECT * FROM DCS_PRODUCT_DEVICE;
SELECT * FROM DCS_PRODUCT_ACCESSORY;

SELECT * FROM DCS_PRODUCT WHERE PRODUCT_ID='ac13471';
select * from dcs_product_mas where wms_product_id='6431';
SELECT * FROM DCS_SKU;
SELECT * FROM DCS_SKU DS, DCS_SKU_MAS MS WHERE DS.SKU_ID = MS.SKU_ID and MS.SKU_CODE = 'F8M511TTC00';
SELECT * FROM DCS_SKU DS, DCS_SKU_MAS MS WHERE DS.SKU_ID = MS.SKU_ID;
select * from dcs_prd_chldsku;
SELECT * FROM DCS_PRD_CHLDSKU WHERE SKU_ID='sku30316';
select * from dcs_media where MEDIA_ID='mini5594';

select * from vzw_dcs_sku_id_mapping where sku_id='sku30316';

SELECT * FROM VZW_DCS_SKU_ID_MAPPING;
DESC VZW_DCS_SKU_ID_MAPPING;

SELECT * FROM VZW_DCS_SKU_ID_MAPPING WHERE SKU_ID='sku30316';
select * from vzw_warehouse_accessory_sku where accessory_id='49662';
--52352
--49662
SELECT * FROM VZW_DCS_SKU_ID_MAPPING WHERE MAS_SKU_ID='52352'; 
--sku31249

desc vzw_warehouse_accessory_sku;

SELECT * FROM VZW_DCS_PRODUCT_ID_MAPPING;
DESC VZW_DCS_PRODUCT_ID_MAPPING;
SELECT * FROM DCS_PRD_MEDIA;
SELECT * FROM VZW_PROD_MEDIA;
SELECT * FROM DCS_INVENTORY;
SELECT COUNT(*) FROM VZW_DEVICE_ACCESSORY_COMPAT;
SELECT * FROM VZW_DEVICE_ACCESSORY_COMPAT;
SELECT COUNT(*) FROM VZW_ACCESSORY_DEVICE_COMPAT;


SELECT * FROM VZW_ACCESSORY_REVIEWS;
alter table crs_bill_codes drop constraint CRS_BILL_CODES_F;

ALTER TABLE DCS_PRD_DEVACCES DROP CONSTRAINT SYS_C0016271;

ALTER TABLE CRS_SHIP_CODES DROP CONSTRAINT CRS_SHIP_CODES_F;
SELECT * FROM CRS_CATALOG;
ALTER TABLE CRS_CATALOG DROP CONSTRAINT CRS_CATALOG_F;

SELECT * FROM DCS_SKU_MAS;
SELECT * FROM DCS_SKU_MAS WHERE SKU_CODE is not null;

desc dcs_media;



SELECT owner, table_name
  FROM ALL_CONSTRAINTS
 WHERE constraint_name = 'SYS_C0016281';

SELECT * FROM DCS_PRICE;
SELECT * FROM DCS_PRICE WHERE LIST_PRICE=0;
SELECT * FROM DCS_PRD_CHLDSKU WHERE PRODUCT_ID='acc40065';
SELECT * FROM DCS_PRICE WHERE SKU_ID IN (SELECT SKU_ID FROM DCS_PRD_CHLDSKU WHERE PRODUCT_ID='acc40065');


---------------------------
select * from atgcata.dcs_product;

select * from atgcata.dcs_product where product_id='dev6160008';

select * from atgcata.vzw_prd_device;

select * from atgcata.vzw_prd_device where product_id='dev6160008';

/* Formatted on 8/11/2016 7:52:36 PM (QP5 v5.252.13127.32867) */
SELECT P.PRODUCT_ID,
       P.display_name,
       p.product_type,
       p.manufacturer,
       D.BATTERY,
       D.DIGITAL_STANDBY,
       D.DIGITAL_USAGE,
       D.CAMERA_INFO_TEXT,
       D.MEMORY,
       D.SOR_DEVICE_CATEGORY
  FROM atgcata.dcs_product p, atgcata.vzw_prd_device d
 WHERE P.PRODUCT_ID = D.PRODUCT_ID AND P.PRODUCT_ID = 'dev2160016';
 
select * from atgcata.vzw_phone_capabilities;

--count: 11644
select * from atgcata.vzw_phone_capability;

/* Formatted on 8/11/2016 7:56:57 PM (QP5 v5.252.13127.32867) */
SELECT phone_capability_id,
       phone_cap_display_name,
       key_capability_text,
       key_capability_image,
       key_capability_small_image
  FROM atgcata.vzw_phone_capability
 WHERE phone_capability_id IN (SELECT phone_capability_id
                                 FROM atgcata.vzw_phone_capabilities
                                WHERE product_id = 'dev6160008');
                                
SELECT B.SEQUENCE_NUM,
       a.phone_capability_id,
       a.phone_cap_display_name,
       a.key_capability_text,
       a.key_capability_image,
       a.key_capability_small_image
  FROM atgcata.vzw_phone_capability a, atgcata.vzw_phone_capabilities b
 WHERE a.phone_capability_id IN (SELECT phone_capability_id
                                 FROM atgcata.vzw_phone_capabilities
                                WHERE product_id = 'dev2160016')
   AND B.PHONE_CAPABILITY_ID = A.PHONE_CAPABILITY_ID
   AND B.PRODUCT_ID = 'dev2160016';                                
   
SELECT B.SEQUENCE_NUM,
       a.phone_capability_id,
       a.phone_cap_display_name,
       a.key_capability_image,
       a.key_capability_small_image
  FROM atgcata.vzw_phone_capability a, atgcata.vzw_phone_capabilities b
 WHERE a.phone_capability_id IN (SELECT phone_capability_id
                                 FROM atgcata.vzw_phone_capabilities
                                WHERE product_id = 'dev2160016')
   AND B.PHONE_CAPABILITY_ID = A.PHONE_CAPABILITY_ID
   AND B.PRODUCT_ID = 'dev2160016'
   AND B.SEQUENCE_NUM < 6;   
   
   
select * from cata.dcspp_claimable;  

-----------------------------
desc pub.dcs_product;
desc pub.yc_product;
desc pub.yc_prd_xlate;
desc pub.yc_sku_xlate;


------- PROMOTIONS -----
select * from cata.dcs_promotion where promotion_id in ('promo6880001', 'promo5450014');

select * from pub.dcs_product;

SELECT
    t1.category_id,
    t3.workspace_id
FROM
    dcs_cat_chldprd   t1,
    dcs_product       t2,
    dcs_category      t3
WHERE
    t2.product_id = t1.child_prd_id
    AND t2.asset_version = t1.sec_asset_version
    AND t2.is_head = :1
    AND t2.version_editable = :2
    AND t3.category_id = t1.category_id
    AND t3.asset_version = t1.asset_version
    AND t3.version_editable = :3
    AND ( t3.category_type IS NULL );
    
SELECT
    t1.child_prd_id,
    t3.workspace_id
FROM
    dcs_cat_chldprd   t1,
    dcs_category      t2,
    dcs_product       t3
WHERE
    t2.category_id = t1.category_id
    AND t2.asset_version = t1.asset_version
    AND t2.is_head = :1
    AND t2.version_editable = :2
    AND t3.product_id = t1.child_prd_id
    AND t3.asset_version = t1.sec_asset_version
    AND t3.version_editable = :3
    AND ( t3.product_type IS NULL )    