SELECT COUNT(*)
  FROM yc_user              yc,
       dps_credit_card      crd,
       dps_usr_creditcard   cc
 WHERE yc.user_id = cc.user_id
   AND cc.credit_card_id = crd.id
   AND yc.site_id NOT IN ('ycUKSite', 'ycUKMobileSite')
   AND crd.expiration_year >= 2021;


select count(*) from core.yc_user_subscriptions;
select * from core.yc_user_subscriptions;
select count(*) from core.yc_usr_subscription_mapping;
select * from core.yc_usr_subscription_mapping;
select * from CORE.yc_usr_subscription_mapping where id='69300120';

select count(*) from core.yc_subscriptions;
select * from core.yc_subscriptions;

-- MailOptOutExtractConfiguration
select count(*) from core.yc_subscriptions where subscription_type=1 and opt_in=0;

-- thirdPartyMailSubscription
select count(*) from core.yc_subscriptions where subscription_type=4 and opt_in=0;

--CatalogRequestExtractConfiguration
select count(*) from core.yc_subscriptions;

select * from core.yc_email_subscription;

select * from core.dps_credit_card;

select * from core.dcs_user;
select * from core.dcs_user where default_creditcard is not null;

select count(*)  from core.yc_user where  og_sub_user = '1';
select *  from core.yc_user;

select * from dps_usr_creditcard;

select user_id from (
select count(u.user_id) as COUNT, u.user_id 
  from core.dcs_user u
  join core.yc_user ycu ON ycu.user_id = u.user_id
  join core.dps_usr_creditcard dpscc ON dpscc.user_id = ycu.user_id
 where ycu.og_sub_user = '1'
group by u.user_id) where count = 1; 

SELECT count(*)
FROM
    core.dcs_user             u,
    core.dps_credit_card      cc,
    core.dps_usr_creditcard   ucc
WHERE
    u.user_id IN (
        SELECT user_id
        FROM  ( SELECT COUNT(u.user_id) AS count, u.user_id
                FROM
                    core.dcs_user             u
                    JOIN core.yc_user              ycu ON ycu.user_id = u.user_id
                    JOIN core.dps_usr_creditcard   dpscc ON dpscc.user_id = ycu.user_id
                WHERE
                    ycu.og_sub_user = '1'
                GROUP BY
                    u.user_id )
        WHERE count = 1 )
    AND u.user_id = ucc.user_id
    AND cc.id = ucc.credit_card_id
    AND cc.expiration_year = 2020
    AND cc.expiration_month < 9;

SELECT COUNT(*)
  FROM core.yc_user u
 WHERE u.og_sub_user = '1';
    
select * 
  from core.dcs_user u
  join core.yc_user ycu ON ycu.user_id = u.user_id
  join core.dps_credit_card cc ON u.default_creditcard = cc.id
 where ycu.og_sub_user = '1'
   and cc.expiration_year < 2020;
   
select * 
  from core.dcs_user u
  join core.yc_user ycu ON ycu.user_id = u.user_id
  join core.dps_credit_card cc ON u.default_creditcard = cc.id
 where ycu.og_sub_user = '1'
   and cc.expiration_year = 2020
   and cc.expiration_month < 9;
  

-------- Users Registration Count --------
--Userid, first name,last name, email, user registration date, last login date, last password update , email status, receive email, last emailed, locale

SELECT
    u.id,
    u.first_name,
    u.last_name,
    u.email,
    u.registration_date,
    u.lastactivity_date,
    u.lastpwdupdate,
    u.email_status,
    u.receive_email,
    u.last_emailed,
    u.locale
FROM
    core.dps_user u
WHERE
    u.registration_date >= TO_DATE('2020-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
ORDER BY u.registration_date ASC;    
    
SELECT count(*)
  FROM core.dps_user u
 WHERE u.registration_date >= TO_DATE('2013-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
   AND u.locale = 1;
-- WHERE u.registration_date BETWEEN TO_DATE('2020-04-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2020-04-21 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
--all: 3363427, US: 1599721

desc core.dps_user;
-------- Users Registration Count --------

select * from core.dps_user;
select * from core.crs_user;
select * from core.yc_user;
select count(*) from core.dps_user where lastactivity_date >= to_char(sysdate-1,'DD/MON/YY');
select * from core.dps_user where login = 'nagams@gmail.com';
select * from core.dps_user where login = 'nagaraja.settra@newellco.com';
select * from core.dps_user where id='97920034';
SELECT
    u.id,
    u.login,
    u.first_name,
    u.last_name,
    s3.subscription_type,
    s3.opt_in,
    s3.creation_date
FROM
    core.dps_user u
    join core.yc_user_subscriptions s1 ON s1.profile_id = u.id
    join core.yc_usr_subscription_mapping s2 ON s2.subscription_list = s1.id
    join CORE.yc_subscriptions s3 ON s3.id = s2.id
WHERE
    u.lastactivity_date >= to_char(sysdate-1,'DD/MON/YY')
    AND s3.opt_in = 0;

SELECT
    count(*)
FROM
    core.dps_user u
    join core.yc_user_subscriptions s1 ON s1.profile_id = u.id
    join core.yc_usr_subscription_mapping s2 ON s2.subscription_list = s1.id
    join CORE.yc_subscriptions s3 ON s3.id = s2.id
WHERE
    --u.lastactivity_date >= to_char(sysdate-7,'DD/MON/YY')
    s3.creation_date > TO_DATE('2019-12-01 12:20:42', 'YYYY-MM-DD HH24:MI:SS')
    --AND s3.subscription_type = 0
    AND source = '1000';
    --AND s3.opt_in = 0;

SELECT
    count(*)
FROM
    core.yc_user_subscriptions s1
    join core.yc_usr_subscription_mapping s2 ON s2.subscription_list = s1.id
    join CORE.yc_subscriptions s3 ON s3.id = s2.id
WHERE
    --u.lastactivity_date >= to_char(sysdate-7,'DD/MON/YY')
    s3.creation_date > TO_DATE('2019-12-01 12:20:42', 'YYYY-MM-DD HH24:MI:SS')
    AND s3.subscription_type = 0
    AND s3.opt_in = 0;
    
SELECT
    u.id,
    u.login,
    u.first_name,
    u.last_name,
    s3.subscription_type,
    s3.opt_in,
    s3.creation_date
FROM
    core.dps_user u
    join core.yc_user_subscriptions s1 ON s1.profile_id = u.id
    join core.yc_usr_subscription_mapping s2 ON s2.subscription_list = s1.id
    join CORE.yc_subscriptions s3 ON s3.id = s2.id
WHERE
    u.login = 'nagams@gmail.com';
    
-------------------

SELECT
    *
FROM
    core.yc_usr_subscription_mapping   m
    INNER JOIN core.yc_user_subscriptions         usr ON m.id = usr.id
    INNER JOIN core.yc_subscriptions              sub ON m.subscription_list = sub.id
    LEFT OUTER JOIN (
        SELECT
            ms.id,
            ad.company_name,
            ad.address1,
            ad.address2,
            ad.city,
            ad.country_code,
            ad.phone,
            ad.state_code,
            ad.zip_code,
            ad.first_name,
            ad.last_name
        FROM
            core.yc_subscription_address   ad
            INNER JOIN core.yc_mail_subscription      ms ON ms.mail_subscription_address = ad.id
    ) tb ON tb.id = sub.id
    LEFT OUTER JOIN core.yc_email_subscription         em ON em.id = sub.id
    LEFT OUTER JOIN core.yc_mobile_subscription        mo ON mo.id = sub.id
WHERE
    creation_date >= sysdate - 1
ORDER By sub.creation_date desc,
         m.id asc, 
         m.seq_no asc;    
    
--------------------
select * from core.das_account;
--2253216944 2262467387
select * from core.dps_user where id='2265601265';
select * from core.dps_user_address where id='2253216944';
-- 2276440666 2284265969 2284265968
select * from core.dps_contact_info where id='2284265968';


-------

select count(*) from core.dcspp_claimable;   


-------------- --------------
-- nylr183@aol.com
select * from core.dps_user where login='nagams@gmail.com';--2226348697
select * from core.dcspp_order where profile_id='2226348697';

 


select * from CORE.YC_ORDER_COUPON where ORDER_ID='w209487401';
select * from CORE.DCS_USR_ACTVPROMO;
select * from CORE.DCS_USR_ACTVPROMO where ID='97181317';--pst693852181--pst693852182
select * from CORE.DCS_PROMO_ST_CPN where STATUS_ID in ('pst693852181','pst693852182');--CSCRPLFSOR

select * from core.dcs_usr_usedpromo where id='226391404'; 

select o.order_id,o.agent_id,o.profile_id, o.creation_date from core.dcspp_order o join
cORE.YC_ORDER_COUPON oc on o.order_id = oc.order_id 
where o.state='INCOMPLETE' and oc.coupon_id = ('CSCRPLFSOR') ;

 

--delete from YC_CORE.DCS_USR_ACTVPROMO where ID='226391404' and PROMO_STATUS_ID in ('pst693852181','pst693852182');--CSCRPLFSOR

 

select * from CORE.DCS_USR_ACTVPROMO where promo_status_id in ('pst693852181','pst693852182');

select * from CORE.DCS_PROMO_ST_CPN where coupon_id  in ('CSCFREEORD', 'CSCFREESHP');

SELECT DISTINCT coupon_id
  FROM core.dcs_promo_st_cpn
 WHERE coupon_id LIKE 'CSC%';

select * from CORE.DCS_PROMO_ST_CPN where status_id in ('pst320730108','pst320730112','pst253500111',
'pst296020119','pst296020117','pst386400091','pst243740097','pst333160051');

select * from CORE.DCS_USR_ACTVPROMO where promo_status_id in ('pst320730108','pst320730112','pst253500111',
'pst296020119','pst296020117','pst386400091','pst243740097','pst333160051');

select count(*) from CORE.DCS_USR_ACTVPROMO where promo_status_id in (SELECT status_id from core.dcs_promo_st_cpn WHERE coupon_id in ('CSCFREEORD', 'CSCFREESHP'));

SELECT count(*)
  FROM core.dcs_usr_actvpromo   p
       JOIN core.dcs_promo_st_cpn    c ON c.status_id = p.promo_status_id
 WHERE
       c.coupon_id like 'CSC%';
       
--       c.coupon_id IN ('CSCFREEORD', 'CSCFREESHP');
       