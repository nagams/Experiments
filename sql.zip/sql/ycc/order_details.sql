SELECT
    o.creation_date,
    o.submitted_date,
    o.order_id,
    o.state,
    sg.shipping_group_id,
    yo.locale,
    sa.first_name,
    sa.last_name,
    sa.address_1,
    sa.address_2,
    sa.address_3,
    sa.city,
    sa.county,
    sa.state,
    sa.postal_code,
    sa.country,
    sa.phone_number,
    sa.email,
    di.catalog_ref_id,
    di.state,
    di.site_id,
    dip.list_price,
    dip.sale_price,
    di.quantity
FROM
    core.dcspp_order        o
    JOIN core.yc_dcspp_order     yo ON yo.order_id = o.order_id
    JOIN core.dcspp_ship_group   sg ON sg.order_ref = o.order_id
    JOIN core.dcspp_ship_addr    sa ON sa.shipping_group_id = sg.shipping_group_id
    JOIN core.dcspp_item         di ON di.order_ref = o.order_id
    JOIN core.dcspp_item_price   dip ON dip.amount_info_id = di.price_info
WHERE
    o.order_id = 'w2514459576';
--    o.profile_id = '1017775119';

desc core.yc_dcspp_order;

SELECT
    o.submitted_date,
    o.order_id,
    o.state,
    sg.shipping_group_id,
    yo.locale,
    sa.first_name,
    sa.last_name,
    sa.address_1,
    sa.address_2,
    sa.address_3,
    sa.city,
    sa.county,
    sa.state,
    sa.postal_code,
    sa.country,
    sa.phone_number,
    sa.email,
    di.catalog_ref_id,
    di.state,
    di.site_id,
    dip.list_price,
    dip.sale_price,
    di.quantity
FROM
    core.dcspp_order        o
    JOIN core.yc_dcspp_order     yo ON yo.order_id = o.order_id
    JOIN core.dcspp_ship_group   sg ON sg.order_ref = o.order_id
    JOIN core.dcspp_ship_addr    sa ON sa.shipping_group_id = sg.shipping_group_id
    JOIN core.dcspp_item         di ON di.order_ref = o.order_id
    JOIN core.dcspp_item_price   dip ON dip.amount_info_id = di.price_info
WHERE
    o.state = 'IN_WAREHOUSE'
    AND yo.locale IN (
        'it_IT',
        'de_DE',
        'fr_FR',
        'en_GB'
    )
    AND sg.shipping_group_id LIKE 'cl%'
    AND o.submitted_date > TO_DATE('2020-12-01 11:15:00', 'YYYY-MM-DD HH24:MI:SS');

desc core.yc_dcspp_order;

SELECT ssn, a.* FROM ATGCORE.VZW_ONLINE_ORDER A WHERE SSN is not NULL AND ROWNUM < 10;

SELECT ssn, a.order_id, B.site_id, B.SUBMITTED_DATE, B.CREATION_DATE, B.LAST_MODIFIED_DATE, B.STATE, A.CLIENT_ORDER_TYPE
  FROM CORE.DCSPP_ORDER A,
       CORE.yc_dcspp_order b
 WHERE 
   a.order_id = b.order_id
   AND B.SUBMITTED_DATE > sysdate-1
   --AND ssn != 'rm6anFP0SgI='
  -- AND A.CLIENT_ORDER_TYPE not in ('ACCNLND', 'ACCNLNDEMP', 'NPPSLND')
   AND B.STATE  in ('PROCESSED', 'SUBMITTED')
--   AND B.SITE_ID = '400001'
   ORDER BY b.CREATION_DATE desc;
 
--s161034544 11:02:24,  s161035318

SELECT count(*)
  FROM CORE.DCSPP_ORDER A,
       CORE.yc_dcspp_order b
 WHERE a.order_id = b.order_id
   AND A.SUBMITTED_DATE >= TO_DATE('2020-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
   AND A.STATE  in ('IN_WAREHOUSE', 'SHIPPED', 'REPLACEMENT_ORDER', 'PENDING_SHIPMENT')
--   AND B.ORDER_TYPE in ('SUBSCRIBED_ORDER', 'REPLENISHMENT_ORDER')
   AND B.ORDER_TYPE in ('REPLENISHMENT_ORDER')
--   AND B.SITE_ID = '400001'
   ORDER BY A.SUBMITTED_DATE desc;
   
---------
SELECT a.order_id, a.site_id, a.state, a.creation_date
  FROM core.dcspp_order a
 WHERE a.state != 'INCOMPLETE'
   AND a.profile_id IN (SELECT id
                          FROM core.dps_user
                         WHERE login = 'nagams@gmail.com')
ORDER BY a.CREATION_DATE desc;

select * from core.dps_user where login='97950744';

-- 2264849340 2264766305  2264849395 
SELECT a.order_id, a.site_id, a.state, a.creation_date
  FROM core.dcspp_order a
 WHERE 
   -- a.state = 'INCOMPLETE'
      a.profile_id = '1017775119'
ORDER BY a.CREATION_DATE desc;

select * 
  from core.dcspp_order 
 where order_id in ('qa78883016', 'QA79770011');


select a.order_id, b.site_id, a.auto_saved, b.explicitly_saved , b.state , b.last_modified_date, B.CREATION_DATE 
from atgcore.vzw_online_order a , atgcore.dcspp_order b, atgcore.vzw_order c where a.order_id = b.order_id 
and b.order_id = c.order_id and b.site_id = '400001' 
and b.state = 'INCOMPLETE' and (a.auto_saved = 0 AND b.explicitly_saved = 0)
and b.profile_id = 'SDC26871506';

select * from ATGCORE.BILLTOSHIP_TRANS_LOG where MTN='8142436355';

--Order
SELECT *
  FROM atgcore_ltcom.dcspp_order a, atgcore_ltcom.vzw_order b
 WHERE 
    A.SITE_ID = '400001'
    and b.order_id = a.order_id;
    
SELECT a.order_id,
       a.profile_id,
       a.state,
       a.creation_date,
       a.submitted_date,
       a.last_modified_date,
       a.price_info,
       a.tax_price_info,
       a.creation_site_id,
       a.site_id,
       b.is_credit_write_validated,
       b.optedfornewsletter,
       b.servicezip,
       b.vendor_id,
       b.channel_id,
       B.CREDIT_APPROVAL_STATUS,
       b.int_eligibility_check,
       b.credit_application_num
  FROM atgcore_ltcom.dcspp_order a, atgcore_ltcom.VZW_ORDER b
 WHERE     A.ORDER_ID IN (SELECT order_ref
                            FROM atgcore_ltcom.dcspp_pay_group
                           WHERE payment_group_id IN (SELECT payment_group_id
                                                        FROM atgcore_ltcom.dcspp_bill_addr
                                                       WHERE     first_name =
                                                                    'Nag'
                                                             AND postal_code =
                                                                    '07305'))  
      AND A.ORDER_ID = B.ORDER_ID;                                                                      

desc core.yc_dcspp_order;

-- My order
SELECT a.order_id, a.profile_id, a.state, a.creation_date, a.submitted_date, a.last_modified_date, a.price_info, a.tax_price_info, a.creation_site_id, a.site_id, b.locale, b.order_type
  FROM CORE.dcspp_order a, CORE.yc_dcspp_order b
 WHERE a.order_id = 'w1949785067'
   AND b.order_id = a.order_id;

SELECT a.order_id, a.profile_id, a.state, a.creation_date, a.submitted_date, a.last_modified_date, a.price_info, a.tax_price_info, a.creation_site_id, a.site_id, b.is_credit_write_validated, b.optedfornewsletter, b.servicezip, b.vendor_id,b.channel_id,B.CREDIT_APPROVAL_STATUS,b.int_eligibility_check,b.credit_application_num  
  FROM ATGCORE.dcspp_order a, ATGCORE.VZW_ORDER b, atgcore.vzw_online_order c
 WHERE a.profile_id = 'SDC4510815'
   AND b.order_id = a.order_id
   AND a.order_id = C.ORDER_ID;
       
SELECT count(*)
  FROM atgcore.dcspp_order a, atgcore.vzw_order b, atgcore.vzw_online_order c
 WHERE a.state = 'INCOMPLETE'
   AND b.order_id = a.order_id
   AND a.order_id = C.ORDER_ID
   AND c.is_unified_order is null;

select * from atg_core.dcspp_order_bfly where order_id='31708409645';

--3999590123   3999510126
select a.order_id, a.profile_id, a.state, a.submitted_date, A.LAST_MODIFIED_DATE
from core.dcspp_order a, core.yc_dcspp_order b 
where
   a.order_id in ('w2213792072')
-- a.PROFILE_ID='21169125'
--  b.GOOGLE_ORDER_ID = '267599539731373'
--   A.STATE = 'AUTH_FAILED'
--  and b.reason_code = 'D'
  and a.order_id = b.order_id;


select * from core.dcspp_order_inst where order_id='w1949785067';
  
desc core.dcspp_amount_info;

select * from core.dcspp_amount_info where amount_info_id='ODC219398184';
select * from core.dcspp_amount_info where amount_info_id like 'bf-ai-43';
select * from core.dcspp_order_price where amount_info_id='ai152407604';
select * from core.dcspp_shipitem_sub where amount_info_id='ai60407373';
select * from core.dcspp_taxshipitem where  amount_info_id='ai60407373';
select * from core.dcspp_ntaxshipitem where  amount_info_id='ai60407373';

select * from core.dcspp_amount_info where type=2;
select * from core.dcspp_tax_price where amount_info_id='ai60407552';
select * from core.dcspp_shipitem_tax where amount_info_id='ai60407556';
select * from core.cbp_tax_price;

-- Orders items
select * 
from core.dcspp_item a 
where a.commerce_item_id in 
        (select commerce_items 
           from core.dcspp_order_item 
          where order_id='w1949785067');
          
--  and a.commerce_item_id = b.commerce_item_id; 

select count(*) 
from core.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from core.dcspp_order_item 
          where order_id='w1949785067');

select * from atg_core.dcspp_item where commerce_item_id like 'bf-ci-7';

select * from atg_core.dcspp_item where commerce_item_id like 'bf-ci-11';

select * from atg_core.dcspp_item_bfly where commerce_item_id='ci4341003150';

-- Items price info ids
select price_info 
from core.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from core.dcspp_order_item 
          where order_id='w2175404370'); 
          
-- Items price details          
select * from core.dcspp_item_price where amount_info_id in
 (select price_info 
from core.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from core.dcspp_order_item 
          where order_id='w2529535069')); 

select * from core.dcspp_itmprice_det where amount_info_id='ai923970209';
select * from core.cbp_item_price where item_price_info_id='ai923970211';

select * from core.dcspp_amount_info;
select * from core.dcspp_amtinfo_adj;
select * from core.dcspp_amtinfo_adj where amount_info_id='ai1004607383';
select * from core.dcspp_price_adjust where coupon_id='CSCRPLFSOR';
select * from core.dcspp_price_adjust where adjustment_id in ('pa902641017', 'pa902640988', 'pa902640989');
--pa902640987 pa902640988 pa902640989

--Payment groups  w2213792072  w2214371198
select order_id, payment_groups from core.dcspp_order_pg where order_id='w2556676610';

select * from core.dcspp_pay_group where order_ref='w2556676610';


UPDATE atg_core.dcspp_pay_group
   SET amount = '244.95',
       amount_authorized = '244.95',
       amount_debited = '244.95',
       currency_code = 'USD',
       state = 'SETTLED',
       state_detail = 'The payment group was successfully debited.'
 WHERE order_ref = '3396505172';
 
 -- Payment Group Relationships
 
 -- Authorization
 --3443820211, 3442761933
select * from core.dcspp_pay_group where order_ref='w2570150674';
select * from core.dcspp_pay_group where payment_group_id='pg1531689599';
select * from core.dcspp_pay_group where payment_group_id like 'bf-pg%';

select * from core.dcspp_credit_card where payment_group_id = 'pg2219417984';
select * from core.dcspp_credit_card;
select * from core.YC_CREDIT_CARD;
select * from atg_core.dcspp_pay_group where order_ref in ('31677955649','31699086521','31708428199','31701928721','31708409645','31708549282','31300745889','31365638728','31708484199','31701750622','31707318169','31705376292','31708694012','31708719440','31708279776','31707480359','31683329313','31693491181','31705007364','31701732545','31706298993','31708731223','31708438942','31697914333','31706081558','31708518145','31708370048','31706528333','31705026422','31708493534','31707975068','31708424775','31703582484','31708527080','31561597106','31513058719','31578033365','31603600282','31497459756','31604586179')
and type = 1;

SELECT *
FROM atg_core.dcspp_credit_card
WHERE payment_group_id IN
  (SELECT payment_group_id
  FROM atg_core.dcspp_pay_group
  WHERE order_ref in ('31677955649','31699086521','31708428199','31701928721','31708409645','31708549282','31300745889','31365638728','31708484199','31701750622','31707318169','31705376292','31708694012','31708719440','31708279776','31707480359','31683329313','31693491181','31705007364','31701732545','31706298993','31708731223','31708438942','31697914333','31706081558','31708518145','31708370048','31706528333','31705026422','31708493534','31707975068','31708424775','31703582484','31708527080','31561597106','31513058719','31578033365','31603600282','31497459756','31604586179')
  );

                             
select * from core.dcspp_bill_addr where payment_group_id='pg2577749957';                             
SELECT *
  FROM core.dcspp_auth_status
 WHERE payment_group_id IN (SELECT payment_group_id
                              FROM core.dcspp_pay_group
                             WHERE order_ref = 'w2224536726');

--select * from core.dcspp_pay_inst;
select * from core.dcspp_auth_status;
select * from core.dcspp_auth_status where payment_group_id='pg2219417984';

select * from atg_core.dcspp_debit_status where  payment_group_id='pg1529096938';
select * from core.dcspp_debit_status where  payment_group_id IN (SELECT payment_group_id
                              FROM core.dcspp_pay_group
                             WHERE order_ref = 'w2224536726');
                             
select * from core.dcspp_pay_status where status_id in (select debit_status from core.dcspp_debit_status where  payment_group_id IN (SELECT payment_group_id
                              FROM core.dcspp_pay_group
                             WHERE order_ref = 'w2224536726'));
                             
select * from core.dcspp_pay_status where status_id in ('ps738989663', 'ps739689825');
select * from core.dcspp_cc_status where status_id ='ps739689825';
--select * from atg_core.dcspp_cardinalpp_status where status_id='ps42470331';

select * from CORE.dcspp_order;
SELECT
    COUNT(*)
FROM
    core.dcspp_pay_status
WHERE
    trans_timestamp BETWEEN TO_DATE('2019-12-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-12-17 23:59:00', 'YYYY-MM-DD HH24:MI:SS' )
    AND trans_success = 1
    AND type = 7;
    
SELECT
    count(*)
FROM
    core.dcspp_pay_status a
    JOIN core.dcspp_debit_status b ON a.status_id = b.debit_status
WHERE
    trans_timestamp BETWEEN TO_DATE('2019-12-17 7:00:34', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-12-17 20:07:37', 'YYYY-MM-DD HH24:MI:SS' )
    AND trans_success = 1
    AND type = 7;
    
    
--Shipping groups
-- sg2166771141, sg2165426545, sg2166771140 (ai903761884, ai903564911, ai903761882)
select * from core.dcspp_order_sg where order_id='w1108661949';
desc core.dcspp_ship_group;
select * from core.dcspp_ship_group where order_ref='w2529535069';
select * from core.dcspp_ship_group where shipping_group_id like 'bf-sg%';
select * from core.dcspp_amount_info where amount_info_id ='ai1004607383';
select * from core.dcspp_ship_price  where amount_info_id in ('ai1007427251', 'ai1004607385', 'ai1004607383');
--select * from core.dcspp_ship_group_bfly where shipping_group_id='sg217730421';
--select * from core.dcspp_hrd_ship_grp where shipping_group_id in (select shipping_group_id from atg_core.dcspp_ship_group where order_ref='3369811346');

select * from core.dcspp_ship_addr where shipping_group_id='sg217730421';
SELECT *
  FROM core.dcspp_ship_addr
 WHERE shipping_group_id IN (SELECT shipping_groups
                              FROM core.dcspp_order_sg
                             WHERE order_id = 'w2181778451');
select * from core.crs_hrd_ship_group where shipping_group_id IN (SELECT shipping_groups
                              FROM core.dcspp_order_sg
                             WHERE order_id = 'w2181778451');
--YC_HARDGOOD_SHIP_GROUP                             
                              
SELECT *
FROM   core.yc_hardgood_ship_group   a
       LEFT JOIN core.dcspp_hrd_ship_grp c ON a.shipping_group_id = c.shipping_group_id
       LEFT JOIN core.yc_wm_s2s_details b ON a.shipping_group_id = b.shipping_group_id
       LEFT JOIN CORE.dcspp_ship_addr d ON a.shipping_group_id = d.shipping_group_id
WHERE
    a.shipping_group_id IN (
        SELECT shipping_groups FROM core.dcspp_order_sg
        WHERE   order_id = 'w2181778451'
    );
    
select * from core.YC_WM_S2S_DETAILS where shipping_group_id IN (SELECT shipping_groups
                              FROM core.dcspp_order_sg
                             WHERE order_id = 'w2181778451');
                             
desc atg_core.dcspp_ship_group_bfly;
--select * from atg_core.dcspp_hand_inst;
--select * from atg_core.dcspp_ship_inst;
--select * from atg_core.dcspp_sg_hand_inst;
select * from core.YC_SG_PYMT_REF;
select * from core.YC_SG_PYMT_REF where shipping_grp_id in ('sg2166771141', 'sg2165426545', 'sg2166771140');

-- Relationships
-- 1> Payment group relationships
select * from core.dcspp_order_rel where order_id='w2529535069';
select * from core.dcspp_relationship where order_ref='3659072061';
select * from core.dcspp_relationship where relationship_id like 'r118742395';
select * from core.dcspp_payorder_rel where order_id='w2214371198';
select * from core.dcspp_payorder_rel where relationship_id like 'bf-r-%';

select * from atg_core.dcspp_relationship where relationship_id='r110781319';

select * from atg_core.dcspp_shipitem_rel where relationship_id in (select relationship_id from atg_core.dcspp_relationship where order_ref='3369811346'); 
-- 2> Shipping group relationships

select * from atg_core.dcspp_rel_orders;
select * from atg_core.dcspp_order_sg where order_id='3369811346';
select * from core.dcspp_order_pg where order_id='w2213792072';
select * from atg_core.dcspp_order_item  where order_id='3370908077';

select * from atgcore.dcspp_order_rel where order_id='s35251723';           

select * from atg_core.dcspp_order_rel where order_id='3369811346' and relationships='r92993282';

