select *  from core.yc_user;
select * from core.dps_user where id='1017775119';

SELECT
    u.id,
    u.first_name,
    u.last_name,
    u.email,
    u.registration_date,
    u.lastactivity_date,
    u.lastpwdupdate,
    u.email_status,
    u.receive_email,
    u.last_emailed,
    u.locale
FROM
    core.dps_user u,
    core.yc_user yu
WHERE
--    u.id in ('2632717774', '2623286337')
      u.login = 'aisha9876@hotmail.co.uk'
    AND u.id = yu.user_id;

SELECT *
  FROM core.dcspp_order o
  INNER JOIN core.yc_dcspp_order yco ON o.order_id = yco.order_id
 WHERE o.order_id in ( 'w2573958378', 'w2565032449', 'w2556676610', 'w2570150674', 'w2578362414' );
 

select * from core.dcspp_order where order_id='w2514459576';

select * from core.dcspp_order where profile_id='1017775119';
 
SELECT *
  FROM core.dcspp_order
 WHERE submitted_date >= TO_DATE('2021-02-20 00:00:00', 'YYYY-MM-DD HH24:MI:SS') 
   AND state != 'INCOMPLETE'; 
   
SELECT  *
 FROM   core.dcspp_order do
 LEFT JOIN core.dps_user du ON do.profile_id = du.id
WHERE
    do.order_id IN (
        SELECT order_id
          FROM core.dcspp_order
         WHERE last_modified_date >= TO_DATE('2021-02-21 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
            AND state != 'INCOMPLETE' )
    AND du.id IS NULL;   
 
SELECT DISTINCT ( do.order_id ), du.email AS profile_email,  to_char(du.registration_date, 'DD-MON-YY') AS user_registration_date,
       to_char(do.submitted_date, 'DD-MON-YY') AS submitted_date,  do.site_id
FROM  yc_core.dcspp_order   do
      LEFT JOIN yc_core.dps_user      du ON do.profile_id = du.id
WHERE
    do.order_id IN (
        SELECT order_id
        FROM yc_core.dcspp_order
        WHERE submitted_date BETWEEN TO_DATE('2020-10-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2021-02-22 23:59:00', 'YYYY-MM-DD HH24:MI:SS' )
            AND state != 'INCOMPLETE'
            AND do.site_id IN ( 'ycMobileSite', 'YCSite', 'WWSite', 'WWMobileSite', 'ycUKSite', 'ycUKMobileSite' )
         )
  AND du.id IS NOT NULL;
  
SELECT
    u.id,
    u.login,
    u.first_name,
    u.last_name,
    u.registration_date,
    o.submitted_date
FROM
    core.dps_user u
    join core.dcspp_order o ON o.profile_id = u.id
    JOIN core.yc_dcspp_order     yo ON yo.order_id = o.order_id
    JOIN core.dcspp_ship_group   sg ON sg.order_ref = o.order_id
    JOIN core.dcspp_ship_addr    sa ON sa.shipping_group_id = sg.shipping_group_id
WHERE
    u.registration_date >= o.submitted_date+1
  AND u.login = sa.email;  

SELECT count(*)
FROM
    core.dps_user u
    join core.dcspp_order o ON o.profile_id = u.id
    JOIN core.yc_dcspp_order     yo ON yo.order_id = o.order_id
    JOIN core.dcspp_ship_group   sg ON sg.order_ref = o.order_id
    JOIN core.dcspp_ship_addr    sa ON sa.shipping_group_id = sg.shipping_group_id
WHERE
    u.registration_date >= o.submitted_date+1
  AND u.login = sa.email;  
    
SELECT count(*)
FROM
    core.dps_user u
    join core.dcspp_order o ON o.profile_id = u.id
    JOIN core.dcspp_pay_group   pg ON pg.order_ref = o.order_id
    JOIN core.dcspp_bill_addr    ba ON ba.payment_group_id = pg.payment_group_id
WHERE
    u.registration_date >= o.submitted_date+1
  AND u.login != ba.email;  

----------
select * from core.dcs_inv_atp;

SELECT *
  FROM core.dcs_inventory a, core.yc_inventory b
 WHERE ROWNUM < 100;
 
SELECT
    EXTRACT(HOUR FROM do.submitted_date),
    COUNT(di.quantity) AS count
FROM
    core.dcspp_order   do,
    core.dcspp_item    di
WHERE
    do.submitted_date BETWEEN TO_DATE('2020-12-02 00:00:01', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2020-12-02 23:59:00', 'YYYY-MM-DD HH24:MI:SS' )
    AND do.order_id = di.order_ref
    AND do.site_id IN (
        'YCSite',
        'ycMobileSite',
        'WWSite',
        'WWMobileSite'
    )
    AND di.catalog_ref_id = '1325612'
GROUP BY
    EXTRACT(HOUR FROM do.submitted_date)
ORDER BY
    EXTRACT(HOUR FROM do.submitted_date);


SELECT address_1 || address_2 || address_3 AS full_address,
       length(address_1 || address_2 || address_3) AS addr_length
FROM   core.dcspp_ship_addr
WHERE  ROWNUM <= 100
ORDER BY
    addr_length DESC;

SELECT COUNT(*)
FROM (
       SELECT DISTINCT(full_address), addr_length
       FROM (SELECT address_1 || address_2 || address_3 AS full_address,
                    length(address_1 || address_2 || address_3) AS addr_length
             FROM core.dcspp_ship_addr
             WHERE country != 'US')
        WHERE
            addr_length > 35
    );

SELECT DISTINCT(full_address), country, addr_length
  FROM (SELECT address_1 || address_2 || address_3 AS full_address,
               country, 
               length(address_1 || address_2 || address_3) AS addr_length
        FROM core.dcspp_ship_addr
        WHERE country != 'US')
  WHERE addr_length > 35
  ORDER BY addr_length DESC;

    
SELECT
    concat(address_field1, address_field2, address_field3, address_field4, address_field5),
    length(concat(address_field1, address_field2, address_field3, address_field4, address_field5))
FROM
    address
order by
    2 desc
fetch first 100 lines;

select SQL_TEXT 
from v$sqltext
where sql_id='d6wdjwm9dsqr8';

select sql_fulltext from sys.v$sql where sql_id='d6wdjwm9dsqr8';

SELECT sql_text FROM v$sql WHERE sql_id = '&_sql_id'; 

select distinct(site_id) from core.dcspp_order;
select distinct(creation_site_id) from core.dcspp_order;
select * from core.dcspp_order;
select * from core.dcspp_order where agent_id is not null;
select distinct(order_type) from core.yc_dcspp_order where order_type is not null;
select * from core.yc_dcspp_order;

------------ CSC Orders Count ----------
SELECT count(*) as COUNT, STATE
  FROM core.dcspp_order
 WHERE agent_id is not null
   AND site_id IN ('YCSite', 'WWSite', 'ycStorePOSSite', 'WWStorePOSSite', 'ycMobileSite')
--   AND site_id IN ('ycUKSite', 'ycUKMobileSite')
   AND submitted_date >= TO_DATE('2020-03-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
GROUP BY state
ORDER BY count DESC;
   
SELECT count(distinct (order_id)) as COUNT, o.STATE, pg.payment_method
  FROM core.dcspp_order o
  INNER JOIN core.dcspp_pay_group pg ON o.order_id = pg.order_ref
 WHERE o.agent_id is not null
   AND o.site_id IN ('YCSite', 'WWSite', 'ycStorePOSSite', 'WWStorePOSSite', 'ycMobileSite')
--   AND site_id IN ('ycUKSite', 'ycUKMobileSite')
   AND o.submitted_date >= TO_DATE('2020-03-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
   AND pg.payment_method != 'storePOS'
   AND pg.amount > 0
GROUP BY o.state, pg.payment_method
ORDER BY count DESC;

SELECT *
  FROM core.dcspp_order o
  INNER JOIN core.dcspp_pay_group pg ON o.order_id = pg.order_ref
 WHERE o.agent_id is not null
   AND o.site_id IN ('YCSite', 'WWSite', 'ycStorePOSSite', 'WWStorePOSSite', 'ycMobileSite')
--   AND site_id IN ('ycUKSite', 'ycUKMobileSite')
   AND pg.payment_method != 'storePOS'
   AND o.submitted_date >= TO_DATE('2020-03-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS');

SELECT count(*) as COUNT, a.agent_id, u.login
  FROM core.dcspp_order a
       LEFT JOIN agent.dpi_user u ON a.agent_id = u.id
 WHERE agent_id is not null
   AND site_id IN ('YCSite', 'WWSite', 'ycStorePOSSite', 'WWStorePOSSite', 'ycMobileSite')
--   AND site_id IN ('ycUKSite', 'ycUKMobileSite')
   AND submitted_date >= TO_DATE('2020-03-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
GROUP BY a.agent_id, u.login   
ORDER BY COUNT DESC;

SELECT a.agent_id, u.login, a.order_id
  FROM core.dcspp_order a
       LEFT JOIN agent.dpi_user u ON a.agent_id = u.id
       INNER JOIN core.dcspp_pay_group pg ON a.order_id = pg.order_ref
 WHERE a.agent_id is not null
--   AND a.site_id IN ('YCSite', 'WWSite', 'ycStorePOSSite', 'WWStorePOSSite', 'ycMobileSite')
   AND site_id IN ('ycUKSite', 'ycUKMobileSite')
   AND a.submitted_date >= TO_DATE('2020-03-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
   AND pg.payment_method = 'creditCard'
   AND pg.amount > 0
GROUP BY a.agent_id, u.login, a.order_id;   

--9570  704
SELECT DISTINCT(agent_id)
  FROM core.dcspp_order
 WHERE agent_id is not null
 --profile_id LIKE 'a%'
   AND site_id IN ('YCSite', 'WWSite', 'ycStorePOSSite', 'WWStorePOSSite', 'ycMobileSite')
   AND submitted_date >= TO_DATE('2020-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS');
    
select count(*) from agent.dpi_user;
desc agent.dpi_user;
------------ CSC Orders Count ----------

SELECT *
  FROM core.dcspp_order o
  INNER JOIN core.yc_dcspp_order yco ON o.order_id = yco.order_id
 WHERE yco.IS_LOYALTY_ORDER = 1;
   --AND o.submitted_date >= TO_DATE('2020-03-13 00:00:00', 'YYYY-MM-DD HH24:MI:SS');

desc core.yc_dcspp_order;

----------- END: Loyalty Orders ----
SELECT
    COUNT(DISTINCT order_ID)
FROM
    core.dcspp_order        o
    JOIN core.dcspp_ship_group   sg ON o.order_id = sg.order_ref
    JOIN core.dcspp_ship_addr    sa ON sg.shipping_group_id = sa.shipping_group_id
WHERE
    o.submitted_date >= TO_DATE('2020-03-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND sa.state = 'CA';  

SELECT
    COUNT(*)
FROM
    core.dcspp_order o
WHERE
    o.submitted_date >= TO_DATE('2017-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND site_id IN ('ycUKSite', 'ycUKMobileSite');
    
--SHIPPING_GROUP_ID, ORDER_REF, STATE
desc core.dcspp_ship_group;
select * from core.dcspp_ship_group;
select * from core.dcspp_ship_group where shipping_group_id = 'sg2370200';
--STATE, COUNTRY
desc core.dcspp_ship_addr;
select * from core.dcspp_ship_addr where shipping_group_id = 'sg2370200';

---- CA: orders -----
SELECT
    DISTINCT order_ID
FROM
    core.dcspp_order        o
    JOIN core.dcspp_item   it ON o.order_id = it.order_ref
WHERE
    o.submitted_date >= TO_DATE('2020-05-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND it.type = 4004;

SELECT
    DISTINCT order_ID
FROM
    core.dcspp_order        o
    JOIN core.dcspp_item   it ON o.order_id = it.order_ref
    JOIN core.dcspp_ship_group   sg ON o.order_id = sg.order_ref
WHERE
    o.submitted_date >= TO_DATE('2020-05-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND it.type = 4004
    AND sg.shipping_method in ('Priority Delivery (2-Day)','Express Delivery (Overnight)','3-day Express','EXPRESS','Next Day Saturday','3 Day Standard','2-day Express','Next Day Priority','3-day Standard','Next Day','Next Day Express'); 
    
desc core.dcspp_item;    
select count(*) from core.dcspp_item where type =4005;

------ GiftBox Orders ---

desc core.dcspp_order;

select * from core.dps_user where id like 'a%';

SELECT a.site_id,  count(*)
  FROM core.dcspp_order a
 WHERE a.state = 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY')
   group by a.site_id;
   
SELECT *
  FROM core.dcspp_order a
 WHERE a.state != 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY');

SELECT a.site_id, count(*)
  FROM core.dcspp_order a
 WHERE a.state != 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY')
   group by a.site_id;

--SELECT count(*)
SELECT *
  FROM core.dcspp_order a
 WHERE a.state = 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-14,'DD/MON/YY');

SELECT a.order_id, a.site_id, a.last_modified_date, a.CREATION_DATE
  FROM core.dcspp_order a
 WHERE a.state = 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY')
   ORDER BY a.last_modified_date desc;

SELECT count(a.order_id), a.order_id, a.last_modified_date
  FROM core.dcspp_order a,
       CORE.dcspp_order_item oi
 WHERE a.state = 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY')
   AND a.order_id = oi.order_id
   GROUP BY a.order_id, a.last_modified_date 
   ORDER BY a.last_modified_date desc;

SELECT count(a.order_id) as line_count, a.order_id, a.last_modified_date
  FROM core.dcspp_order a,
       CORE.dcspp_order_item oi
 WHERE a.state = 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY')
   AND a.order_id = oi.order_id
   GROUP BY a.order_id, a.last_modified_date 
   ORDER BY line_count desc;

SELECT a.order_id
  FROM core.dcspp_order a,
       CORE.dcspp_order_item oi
 WHERE a.state = 'INCOMPLETE'
   AND a.creation_date >= to_char(sysdate-1,'DD/MON/YY')
   AND a.order_id = oi.order_id
   ORDER BY a.last_modified_date desc;

select * from core.dcspp_order_item;   
select * from core.dcspp_order_item where order_id = 'w2217736910';   

select count(*) 
from core.dcspp_item 
where commerce_item_id in 
        (select commerce_items 
           from core.dcspp_order_item 
          where order_id='w2217736910');

select * from core.dcspp_item;

select * from core.YC_SG_PYMT_REF;

SELECT
    do.order_id,
    SUM(dai.amount + dop.shipping + dop.tax) AS order_total,
    do.submitted_date,
    do.state,
    do.site_id
FROM
    core.dcspp_order         do,
    core.dcspp_order_price   dop,
    core.dcspp_amount_info   dai
WHERE
    do.price_info = dai.amount_info_id
    AND dop.amount_info_id = do.price_info
    AND do.submitted_date BETWEEN TO_DATE('2019-12-16 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-12-16 23:59:00', 'YYYY-MM-DD HH24:MI:SS'
    )
    AND do.agent_id IS NOT NULL
GROUP BY
    do.order_id,
    do.submitted_date,
    do.state,
    do.site_id;

------- Orders purge --------
SELECT
    *
FROM
    core.dcspp_order   do
    LEFT JOIN core.dps_user      du ON do.profile_id = du.id
WHERE
    do.order_id IN (
        SELECT
            order_id
        FROM
            core.dcspp_order
        WHERE
            last_modified_date BETWEEN TO_DATE('2019-12-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-12-30 23:59:00',
            'YYYY-MM-DD HH24:MI:SS')
            AND state = 'INCOMPLETE'
    )
    AND du.id IS NULL;

SELECT
    COUNT(do.order_id)
FROM
    core.dcspp_order   do
    LEFT JOIN core.dps_user      du ON do.profile_id = du.id
WHERE
    do.last_modified_date BETWEEN TO_DATE('2020-01-07 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2020-01-07 23:59:00', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND du.id IS NULL;
    

------------------------------------------------
--cartsSql
SELECT
    ord.order_id
FROM
    core.dcspp_order   ord
    LEFT JOIN core.dps_user      usr ON ord.profile_id = usr.id
WHERE
    ord.last_modified_date < TO_DATE('2020-01-20 03:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND ord.last_modified_date > TO_DATE('2020-01-19 03:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND usr.id IS NULL
    ORDER BY ord.order_id ASC;

SELECT
    count(ord.order_id)
FROM
    core.dcspp_order   ord
    LEFT JOIN core.dps_user      usr ON ord.profile_id = usr.id
WHERE
    ord.last_modified_date < TO_DATE('2020-01-12 12:54:03', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND usr.id IS NULL
    ORDER BY ord.order_id ASC;

select * from core.yc_scheduled_jobs;

--nextRangeCartsSql
SELECT
    ord.order_id
FROM
    core.dcspp_order   ord
    LEFT JOIN core.dps_user      usr ON ord.profile_id = usr.id
WHERE
    ord.last_modified_date < TO_DATE('2020-01-10 12:51:42', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND ord.order_id > 'w1352451151'
    AND usr.id IS NULL
    ORDER BY ord.order_id ASC;

--firstBatchCartsRangeSql
SELECT
    ord.order_id
FROM
    core.dcspp_order   ord
    LEFT JOIN core.dps_user      usr ON ord.profile_id = usr.id
WHERE
    ord.last_modified_date < TO_DATE('2020-01-10 12:51:42', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND ord.order_id >= 'w1352451151' AND ord.order_id <= 'w1468684856'
    AND usr.id IS NULL
    ORDER BY ord.order_id ASC;

--cartsRangeSql
SELECT
    ord.order_id
FROM
    core.dcspp_order   ord
    LEFT JOIN core.dps_user      usr ON ord.profile_id = usr.id
WHERE
    ord.last_modified_date < TO_DATE('2020-01-10 12:51:42', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND ord.order_id > 'w1352451151' AND ord.order_id <= 'w1468684856'
    AND usr.id IS NULL
    ORDER BY ord.order_id ASC;
-------
SELECT
    *
FROM
    core.dcspp_order   do
    LEFT JOIN core.dps_user      du ON do.profile_id = du.id
WHERE
    do.last_modified_date < TO_DATE('2019-01-14 12:51:42', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND do.order_id >= 'perf63453337' AND do.order_id <= 'qa63380399';

--('2019-11-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-12-31 23:59:00', 'YYYY-MM-DD HH24:MI:SS')    
SELECT
    count(*)
FROM
    core.dcspp_order   do
    LEFT JOIN core.dps_user      du ON do.profile_id = du.id
WHERE
    do.last_modified_date BETWEEN TO_DATE('2019-11-02 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-11-02 23:59:00', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE'
    AND du.id IS NULL;

SELECT
    count(*)
FROM
    core.dcspp_order
WHERE
    last_modified_date BETWEEN TO_DATE('2019-11-02 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-11-02 23:59:00', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE';

    
SELECT
    count(*)
FROM
    core.dcspp_order
WHERE
    last_modified_date < TO_DATE('2020-01-14 12:51:42', 'YYYY-MM-DD HH24:MI:SS')
    AND state = 'INCOMPLETE';
    
----------------------

SELECT DISTINCT
    ( o.order_id ),
    o.creation_date,
    o.submitted_date,
    o.agent_id,
    o.state,
    pg.amount,
    pg.payment_group_id
FROM
    yc_core.dcspp_order    o,
    yc_core.dcspp_item     di,
    core.dcspp_order_pg    opg,
    core.dcspp_pay_group   pg
WHERE
    di.order_ref = o.order_id
    AND o.submitted_date BETWEEN TO_DATE('2019-12-26 00:00:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2019-12-26 23:59:00', 'YYYY-MM-DD HH24:MI:SS')
    AND di.item_class_type = 'giftCardCommerceItem'
    AND opg.order_id = o.order_id
    AND opg.order_id = pg.order_ref;

-----------------------    

select * from core.csr_order_appeasements where order_id in ('qa77060057','qa76820011','qa77060010','qa77060006','qa76990049','qa76990033','qa76990029','qa76990010','qa76820011','qa76610040','qa76287743','qa69571193','qa69953647','qa66390931','qa66390773');

select * from core.oms_dcspp_order where order_id in ('qa77060032');

settlementFlag = ?0 and state != ?1 and siteId != ?2 and siteId != ?3

select *
from core.dcspp_order o1, 
     core.oms_dcspp_order o2
where 
     o1.order_id = o2.order_id
     AND o1.state !='ERROR'
     AND o1.site_id != 'ycUKSite'
     AND o1.site_id != 'ycUKMobileSite'
     AND o2.settlement_flag = 1;     
     
select *
from core.dcspp_order o1, 
     core.oms_dcspp_order o2
where 
     o1.order_id = o2.order_id
     AND o1.state !='ERROR'
     AND o1.site_id != 'ycUKSite'
     AND o1.site_id != 'ycUKMobileSite'
     AND o2.settlement_flag = 1;
     
SELECT
    o.order_id,
    o.created_by_order,
    o.state    AS orderstate,
    o.submitted_date,
    o.last_modified_date,
    o.site_id,
    o.agent_id,
    yo.locale,
    di.catalog_ref_id,
    oci.cancelled_quantity,
    di.quantity,
    di.state   AS itemstate,
    ba.email,
    sa.email,
    sg.shipping_method,
    sg.state   AS sgstate,
    sg.shipping_group_id
FROM
    core.dcspp_order         o
    JOIN core.yc_dcspp_order      yo ON yo.order_id = o.order_id
    JOIN core.dcspp_item          di ON di.order_ref = o.order_id
    JOIN core.oms_commerce_item   oci ON di.commerce_item_id = oci.commerce_item_id
    JOIN core.dcspp_pay_group     bg ON bg.order_ref = o.order_id
    JOIN core.dcspp_ship_group    sg ON sg.order_ref = o.order_id
    JOIN core.dcspp_bill_addr     ba ON ba.payment_group_id = bg.payment_group_id
    JOIN core.dcspp_ship_addr     sa ON sa.shipping_group_id = sg.shipping_group_id
WHERE
    o.submitted_date BETWEEN TO_DATE('2020-11-25 00:00:01', 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE('2020-12-18 23:59:00', 'YYYY-MM-DD HH24:MI:SS' )
    AND yo.locale = 'it_IT';
    
---------------

SELECT
    do.profile_id, COUNT(do.order_id) as c
FROM
    core.dcspp_order   do
WHERE
    do.last_modified_date > TO_DATE('2019-09-07 00:00:00', 'YYYY-MM-DD HH24:MI:SS') 
    --AND do.profile_id in ('30321011', '29936543', '337851892', '2206762676', '2376023479', '2376023820', '2376023945')
    GROUP BY do.profile_id;

select * from (
SELECT
    do.profile_id, COUNT(do.order_id) as c
FROM
    core.dcspp_order   do
WHERE
    do.last_modified_date > TO_DATE('2019-09-07 00:00:00', 'YYYY-MM-DD HH24:MI:SS') 
    --AND do.profile_id in ('30321011', '29936543', '337851892', '2206762676', '2376023479', '2376023820', '2376023945')
    GROUP BY do.profile_id
    ) where c > 20 order by c desc;
    
    
SELECT
    t1.order_id,
    t1.type
FROM
    dcspp_order t1
WHERE ( ( t1.creation_date >= :1 )
        AND ( t1.creation_date <= :2 )
        AND ( t1.state = :3 ) AND (( t1.sit
 e_id = :4 ) OR (t1.site_id = :5 )))
 
 
SELECT
    "A2"."ORDER_ID",
    "A2"."PROFILE_ID",
    "A2"."STATE",
    "A2"."CREATED_BY_ORDER",
    "A
 2"."CREATION_DATE",
    "A2"."LAST_MODIFIED_D
 ATE",
    "A1"."SHIPPING_GROUP_ID",
    "A1"."SHIP
 _ON_DATE",
    "A1"."STATE",
    "A1"."ORDER_REF"
FROM
    "YC_CORE"."DCSPP_ORDER" "A2",
    "YC_CO
 RE"."DCSPP_SHIP_GROUP" "A1"
WHERE
    "A2"."
 ORDER_ID" = "A1"."ORDER_REF" (+)
    AND "A1"."
 SHIP_ON_DATE" (+) IS NOT NULL
    AND "A2"."C
 REATION_DATE" > sysdate@! - :1 
 
 
ycc-prd-chi-app-02-p 417 CORE a653r2pkr6knh 

SELECT
    do.order_id
FROM
    yc_core.dcspp_order do, yc_core.dcspp_item di, yc_core.d
 cspp_order_item doi where (do.order_id=d
 oi.order_id and doi.COMMERCE_ITEMS=di.co
 mmerce_item_id) and do.site_id in ('YCSi
 te','WWSite') group by do.order_id havin
 g sum(di.quantity) >= :1;
 
 ------------------
 -- Adding indexes
 select * from core.tkt_ticket;
 
SELECT do.order_id
FROM   yc_core.dcspp_order      do,
       yc_core.dcspp_item       di,
       yc_core.dcspp_order_item doi
WHERE  ( do.order_id = doi.order_id AND doi.commerce_items = di.commerce_item_id )
  AND do.site_id IN ('YCSite', 'WWSite')
GROUP BY do.order_id
HAVING SUM(di.quantity) >= :1;

SELECT t1.order_id,
       t1.type
  FROM dcspp_order      t1,
       dcspp_order_sg   t2
 WHERE t2.order_id = t1.order_id
   AND ( t2.shipping_groups = :1 );
   
SELECT sequence_num,
       adjustments
 FROM  dcspp_amtinfo_adj
WHERE  amount_info_id = :1
ORDER BY 1 ASC;  

--6bdypkxdm1xp2
SELECT district_tax
  FROM crs_tax_price
 WHERE amount_info_id = :1;

--55d0cwd9x2cny 
SELECT manual_adj_share,
       post_manual_adj_share
 FROM  yc_item_price
WHERE  amount_info_id = :1 ;  


---------
--CSCFREESHP CSCRPLFSOR  -PROD
--
select count(*) from core.dcspp_claimable;
select * from core.dcspp_claimable;
select * from core.dcspp_claimable where claimable_id='CSCRPLFSOR';
select * from core.yc_coupon_details where coupon_id='CSCFREESHP';
select * from core.dcspp_coupon where coupon_id='CSCRPLFSOR';

SELECT *
FROM
    core.dcspp_claimable     c1
    JOIN core.yc_coupon_details   yc ON yc.coupon_id = c1.claimable_id
    JOIN core.dcspp_coupon        c2 ON c2.coupon_id = c1.claimable_id
WHERE
    c1.claimable_id = 'CSCFREEORD';

--promo5450014     promo6170002 -PROD
--promo6880001  --Perf
select * from cata.dcs_promotion where promotion_id in ('promo6880001', 'promo5450014');    